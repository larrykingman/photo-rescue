# 图生图指南

## 目录
- [核心原则](#核心原则)
- [分辨率保持规范](#分辨率保持规范)
- [主体特征识别](#主体特征识别)
- [提示词构建](#提示词构建)
- [平台参数说明](#平台参数说明)
- [一致性验证](#一致性验证)
- [常见问题](#常见问题)

## 核心原则

图生图的核心挑战是**保持主体严格一致性**和**分辨率不变**，只改变光影与氛围。

### 三大铁律（不可违反）

#### 铁律一：分辨率不变
- **输出分辨率必须等于或高于原图分辨率**
- 在提示词中必须明确标注原图分辨率
- 验证时必须检查分辨率是否匹配

#### 铁律二：主体绝对一致
- **人物/角色/场景等主体必须与原图完全一致（除光影不同外）**
- 禁止改变：外貌、姿态、服装、表情、位置、背景结构
- 仅允许改变：光线方向、光质、色调、氛围、背景光影

#### 铁律三：验证必过
- 生成图片后必须通过全部验证项
- 不通过则调整参数重新生成

### 内容冻结协议

| 允许改变 | 禁止改变 |
|---------|---------|
| ✅ 主光方向和强度 | ❌ 人物外貌（面部、发型、体型） |
| ✅ 光质（硬光/柔光） | ❌ 人物姿态和位置 |
| ✅ 色温和色调 | ❌ 服装款式、颜色、图案 |
| ✅ 对比度 | ❌ 人物表情和情绪 |
| ✅ 轮廓光 | ❌ 背景物体位置和结构 |
| ✅ 氛围效果（烟雾、光斑） | ❌ 产品形态和材质纹理 |
| ✅ 背景光影 | ❌ 分辨率、清晰度、画质 |

---

## 分辨率保持规范

### 分辨率记录流程

1. **获取原图分辨率**
   - 使用图像分析脚本或智能体识别
   - 记录格式：`[宽] × [高]` 像素

2. **在提示词中声明分辨率**

**Midjourney**：
```
MUST maintain original resolution: 1920x1080 pixels.
Keep exact resolution, no upscaling or downscaling.
```

**即梦AI/豆包**：
```
严格保持原图分辨率1920×1080不变。
禁止降低分辨率，禁止模糊。
```

**NanoBanana**：
```
(Keep original resolution 1920x1080:1.8),
(No resolution change:1.5), (No downscaling:1.5)
```

**可灵AI**：
```
保持原图分辨率[宽×高]，禁止降低分辨率。
禁止：降低分辨率、模糊处理
```

3. **验证输出分辨率**
   - 检查输出图片分辨率是否等于原图
   - 如分辨率降低，拒绝输出并重新生成

---

## 主体特征识别

在生成图生图提示词之前，必须先仔细识别原图的所有主体特征。

### 外貌特征（必须保持）
- **年龄段**：青年/中年/老年
- **发型**：颜色、长度、卷直、造型
- **脸型**：圆脸/方脸/瓜子脸/长脸
- **眼睛**：大小、形状、单双眼皮、颜色
- **鼻子**：高/塌、宽/窄
- **嘴唇**：厚/薄、形状
- **其他特征**：痣、疤痕、皱纹等

### 姿态与动作（必须保持）
- **身体姿态**：站立/坐着/躺下/侧身/正面
- **手部位置**和动作
- **头部倾斜角度**
- **腿部和脚的摆放**

### 服装与配饰（必须保持）
- **服装类型**：T恤/连衣裙/西装等
- **服装颜色和图案**
- **配饰**：眼镜、帽子、项链、手表等

### 表情（必须保持）
- **基本表情**：微笑/严肃/惊讶/思考等
- **眼神方向**
- **微表情细节**：如嘴角的弧度

### 原有光影（需要记录，但可能改变）
- 主光方向
- 光质（硬光/柔光）
- 对比度
- 环境光颜色

---

## 提示词构建

### 标准构建流程

#### 第一步：分辨率声明（必须首先声明）

**Midjourney**：
```
MUST maintain original resolution: [WIDTH]x[HEIGHT] pixels.
```

**即梦AI/豆包**：
```
严格保持原图分辨率[宽]×[高]不变。
```

**NanoBanana**：
```
(Keep original resolution [WIDTH]x[HEIGHT]:1.8)
```

#### 第二步：主体保留声明

**Midjourney**：
```
MUST strictly maintain: Character's appearance, pose, clothing, expression from reference image.
Keep character EXACTLY the same, ONLY change lighting.
```

**即梦AI/豆包**：
```
严格保持原图人物的外貌、姿态、服装、表情、位置完全不变。
仅改变光影效果，人物与原图完全一致。
```

**NanoBanana**：
```
(Keep character exactly same:1.8), (Keep pose unchanged:1.5),
(Keep clothing unchanged:1.5), (Keep expression unchanged:1.5)
```

#### 第三步：详细主体特征描述

**示例**（以一张25岁女性人像为例）：

**Midjourney / NanoBanana**：
```
Character: 25-year-old female with long black hair, oval face, big eyes,
high nose, thin lips. Wearing white cotton dress, standing pose,
gentle smile, looking at right.
```

**即梦AI/豆包**：
```
人物特征（必须保留）：
- 约25岁女性，黑色长发披肩，直顺
- 瓜子脸，大眼睛双眼皮，高鼻梁，薄唇
- 站立姿态，身体正面，头部微向右侧倾斜15度
- 身穿白色棉质连衣裙，无领短袖，及膝长度
- 表情微笑，嘴角上扬，眼神温柔地看向画面右侧
```

#### 第四步：明确改造目标（仅光影）

**Midjourney**：
```
ONLY change lighting and atmosphere:
```

**即梦AI/豆包**：
```
仅改变光影和背景：
```

**NanoBanana**：
```
ONLY change lighting and atmosphere:
```

#### 第五步：添加负面提示词

**Midjourney / NanoBanana**：
```
--no resolution change, different face, different pose, different clothing, different expression, blurry, downscaling
```

**即梦AI/豆包**：
```
禁止：降低分辨率、改变人物外貌、改变姿态、改变服装、改变表情、模糊处理
```

---

## 完整提示词模板

### Midjourney完整模板
```
MUST maintain original resolution: [WIDTH]x[HEIGHT] pixels.
MUST strictly maintain: Character's appearance, pose, clothing, expression, position from reference image.
Keep character EXACTLY the same as original, ONLY change lighting.

Character: [详细人物描述]
Wearing [服装描述], [姿态描述], [表情描述].

ONLY change lighting and atmosphere:
[风格名称] style, [灯光配置描述].

--ar [宽:高] --iw 2.5 --style raw --v 6.0
--no resolution change, different face, different pose, different clothing, different expression, blurry, downscaling
```

### 即梦AI/豆包完整模板
```
严格保持原图分辨率[宽]×[高]不变。
严格保持原图人物的外貌、姿态、服装、表情、位置完全不变。
仅改变光影效果，人物与原图完全一致。

人物特征（必须保留）：
- [年龄段]，[发型描述]
- [脸型]，[五官描述]
- [姿态描述]
- [服装描述]
- [表情描述]

仅改变光影：
- 风格：[风格名称]
- 灯光：[灯光配置]

禁止：降低分辨率、改变人物外貌、改变姿态、改变服装、改变表情、模糊处理

参考图强度：0.8
```

### NanoBanana完整模板
```
(Keep original resolution [WIDTH]x[HEIGHT]:1.8),
(Keep character exactly same:1.8),
(Keep pose unchanged:1.5), (Keep clothing unchanged:1.5),
(Keep expression unchanged:1.5),

Character: [人物描述], Wearing [服装], [姿态], [表情].

ONLY change lighting:
([风格名称]:1.3), ([灯光描述]),
[氛围描述].

--quality 2 --style cinematic --ar [宽:高] --strength 0.4
--no resolution change, different face, different pose, different clothing, blurry
```

---

## 平台参数说明

### Midjourney图生图参数
```
--ar {Ratio}        # 宽高比（如 2.39:1, 16:9, 1:1）
--iw {2-3}          # Image Weight（图像权重），2-3表示强烈参考原图
--style raw         # 禁用默认审美风格，使用原始风格
--v 6.0             # 使用 Midjourney V6 版本
```

**关键参数：`--iw 2-3`**
- `--iw 2.5-3`：强烈参考，严格保持原图特征（推荐用于图生图）

### 即梦AI/豆包图生图参数
```
参考图强度: {0.6-0.8}  # 0.6-0.8 表示中等到强烈的参考
```

**关键参数：`参考图强度: 0.8`**
- `0.8-0.9`：强烈参考，严格保持原图特征（推荐用于图生图）

### NanoBanana图生图参数
```
--quality 2         # 质量等级（2 为高质量）
--style cinematic   # 电影风格
--ar {ratio}        # 宽高比
--strength 0.4      # 变化强度，0.4 表示较弱的变化，强烈保持原图
```

**关键参数：`--strength 0.4`**
- `0.2-0.4`：较弱变化，强烈保持原图特征（推荐用于图生图）

---

## 一致性验证

生成图片后，**必须**验证以下方面的一致性：

### 分辨率验证（必须首先验证）
- [ ] **输出分辨率 = 原图分辨率**（或更高）
- [ ] **输出清晰度 ≥ 原图清晰度**
- [ ] **输出画质 ≥ 原图画质**

### 人物一致性验证（人像场景）
- [ ] **外貌完全一致**：年龄、发型、脸型、五官
- [ ] **姿态完全一致**：身体角度、手部位置、头部角度
- [ ] **服装完全一致**：款式、颜色、图案
- [ ] **表情完全一致**：眼神方向、嘴角弧度
- [ ] **位置完全一致**：在画面中的位置

### 产品一致性验证（产品场景）
- [ ] **形态完全一致**
- [ ] **材质纹理完全一致**
- [ ] **品牌标识完全一致**
- [ ] **角度位置完全一致**

### 场景一致性验证
- [ ] **背景结构完全一致**
- [ ] **前景元素完全一致**
- [ ] **空间关系完全一致**

### 光影改变验证
- [ ] **光影按预期改变**
- [ ] **氛围按预期呈现**

### 验证不通过的处理

| 问题 | 解决方案 |
|------|---------|
| 分辨率降低 | 拒绝输出，调整参数重新生成 |
| 人物外貌改变 | 增加`--iw`/`参考图强度`，强化主体描述 |
| 姿态改变 | 强化姿态描述，添加负面提示词 |
| 服装改变 | 详细描述服装，添加负面提示词 |
| 光影效果不足 | 增加光影描述权重 |

---

## 常见问题

### Q1: 输出分辨率降低了怎么办？

**解决方案**：
- 在提示词**开头**明确声明原图分辨率
- 添加负面提示词：`no resolution change, no downscaling`
- 如仍降低，拒绝输出并调整参数重新生成

### Q2: 生成图片改变了人物外貌怎么办？

**解决方案**：
- Midjourney：增加 `--iw` 值到 2.5-3
- 即梦AI/豆包：增加 `参考图强度` 到 0.85-0.9
- NanoBanana：降低 `--strength` 到 0.3-0.4
- 在提示词中强化外貌描述（如 `(oval face:1.5)`, `(big eyes:1.3)`）

### Q3: 生成图片改变了人物姿态怎么办？

**解决方案**：
- 在提示词中明确描述姿态（如 `standing pose`, `looking at right`）
- 添加负面提示词（如 `--no different pose`）
- Midjourney：使用 `--iw 3` 强烈参考原图

### Q4: 如何平衡主体一致性和光影改变？

**解决方案**：
- Midjourney：使用 `--iw 2-2.5` 平衡
- 即梦AI/豆包：使用 `参考图强度 0.75-0.8` 平衡
- NanoBanana：使用 `--strength 0.4-0.5` 平衡

### Q5: 生成图片有明显的AI痕迹怎么办？

**解决方案**：
- 添加质感描述：`visible pores`、`film grain`、`subsurface scattering`
- 添加负面提示词：`plastic skin`、`3d render`、`smooth skin`

---

## 示例

### 示例1：改造成伦勃朗光（Midjourney）

**原图信息**：
- 分辨率：1920×1080
- 内容：25岁女性，长发，白裙，站立，微笑，自然光

**提示词**：
```
MUST maintain original resolution: 1920x1080 pixels.
MUST strictly maintain: Character's appearance, pose, clothing, expression, position from reference image.
Keep character EXACTLY the same as original, ONLY change lighting.

Character: 25-year-old female with long black hair, oval face, big eyes,
high nose, thin lips. Wearing white cotton dress, standing pose,
gentle smile, looking at right.

ONLY change lighting and atmosphere:
Rembrandt lighting style, side light from top-left at 45 degrees,
cold blue rim light from behind, low key contrast.

--ar 16:9 --iw 2.5 --style raw --v 6.0
--no resolution change, different face, different pose, different clothing, different expression, blurry
```

### 示例2：改造成电影质感（即梦AI/豆包）

**原图信息**：
- 分辨率：1920×1080
- 内容：中年男性，西装，坐着，严肃，办公室灯光

**提示词**：
```
严格保持原图分辨率1920×1080不变。
严格保持原图人物的外貌、姿态、服装、表情、位置完全不变。
仅改变光影效果，人物与原图完全一致。

人物特征（必须保留）：
- 中年男性，约45岁，黑色短发
- 国字脸，浓眉，眼睛深褐色
- 高鼻梁，厚嘴唇
- 身穿深蓝色西装，白色衬衫，深色领带
- 坐在办公椅上，身体微向前倾，双手放在桌上
- 表情严肃，眼神直接看向镜头

仅改变光影：
- 风格：伦勃朗光
- 灯光：侧前方45度高位光，暖橙色轮廓光

禁止：降低分辨率、改变人物外貌、改变姿态、改变服装、改变表情、模糊处理

参考图强度：0.8
```

### 示例3：改造成悬疑氛围（NanoBanana）

**原图信息**：
- 分辨率：1920×1080
- 内容：年轻女性，休闲装，站着，微笑，自然光

**提示词**：
```
(Keep original resolution 1920x1080:1.8),
(Keep character exactly same:1.8),
(Keep pose unchanged:1.5), (Keep clothing unchanged:1.5),

Character: 20-year-old female, (long wavy brown hair:1.5), (round face:1.3),
blue eyes, button nose, full lips,
casual jeans and t-shirt, standing pose, small smile.

ONLY change lighting:
(Rembrandt lighting from top-left:1.3),
(cold blue rim light:1.2), (low key contrast:1.3),
(volumetric lighting:1.2), (smoky atmosphere:1.1).

--quality 2 --style cinematic --ar 16:9 --strength 0.4
--no resolution change, different face, different pose, different clothing, blurry
```
