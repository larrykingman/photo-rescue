# 平台提示词格式规范

## 目录
- [核心原则](#核心原则)
- [主体特征锁定协议](#主体特征锁定协议)
- [分辨率保持规范](#分辨率保持规范)
- [主体一致性强化](#主体一致性强化)
- [Midjourney格式](#midjourney格式)
- [即梦AI格式](#即梦ai格式)
- [可灵AI格式](#可灵ai格式)
- [NanoBanana格式](#nanobanana格式)
- [完整提示词模板](#完整提示词模板)
- [防变异技巧](#防变异技巧)
- [常见变异问题处理](#常见变异问题处理)

---

## 核心原则

### 四大铁律（所有平台通用，必须严格遵守）

#### 铁律一：分辨率不变
- **输出分辨率必须等于或高于原图分辨率**
- 在提示词**开头**必须声明原图分辨率
- 验证时必须检查分辨率是否匹配

#### 铁律二：主体绝对一致
- **人物/角色/场景等主体必须与原图完全一致（除光影不同外）**
- 禁止改变：外貌、姿态、服装、表情、位置、背景结构
- 仅允许改变：光线方向、光质、色调、氛围

#### 铁律三：主体特征逐项锁定
- **必须逐项详细描述主体特征，不允许笼统描述**
- 人物场景：年龄、性别、发型、脸型、五官、体型、姿态、服装、表情、配饰、位置
- 产品场景：类型、形态、材质、颜色、尺寸、品牌标识、角度
- 场景背景：结构、元素、空间关系、透视

#### 铁律四：同时生成四个平台提示词
- 每次重打光任务必须同时输出：**Midjourney、即梦AI、可灵AI、NanoBanana** 四个平台的完整提示词
- 确保四个平台提示词的光影参数描述一致

---

## 主体特征锁定协议

### ⚠️ 强制要求：必须逐项描述主体特征

#### 人物场景特征清单（必须全部描述）

```
📌 人物特征锁定清单
├── 基本信息
│   ├── 年龄：[具体年龄段，如"约25岁"]
│   ├── 性别：[男/女]
│   └── 体型：[瘦削/标准/健壮/丰满]
├── 头部特征
│   ├── 发型：[颜色+长度+卷直+造型]
│   ├── 脸型：[圆脸/方脸/瓜子脸/长脸/国字脸]
│   ├── 额头：[宽/窄/高/低]
│   └── 肤色：[白皙/小麦色/深色等]
├── 五官细节
│   ├── 眉毛：[浓/淡/粗/细/形状]
│   ├── 眼睛：[大小+形状+单双眼皮+颜色+眼神方向]
│   ├── 鼻子：[高/塌/宽/窄/鼻头形状]
│   ├── 嘴唇：[厚/薄/形状+唇色]
│   └── 特征标记：[痣/疤痕/酒窝等]
├── 姿态动作
│   ├── 身体朝向：[正面/侧面/背面/角度]
│   ├── 头部角度：[正视/仰视/俯视/倾斜方向和角度]
│   ├── 手部位置：[具体描述双手位置和动作]
│   ├── 腿部姿态：[站立/坐着/交叉/分开]
│   └── 身体重心：[左/右/均匀]
├── 服装配饰
│   ├── 上装：[类型+颜色+材质+款式细节]
│   ├── 下装：[类型+颜色+材质+款式细节]
│   ├── 鞋子：[类型+颜色]
│   ├── 配饰：[眼镜/帽子/项链/手表/耳环等]
│   └── 服装状态：[整洁/褶皱/松紧]
├── 表情情绪
│   ├── 基本表情：[微笑/严肃/惊讶/思考/悲伤等]
│   ├── 嘴角状态：[上扬/平直/下垂]
│   └── 眼神：[温柔/锐利/迷茫/坚定等]
└── 画面位置
    ├── 主体在画面中的位置：[居中/偏左/偏右/偏上/偏下]
    └── 主体占比：[特写/半身/全身/远景]
```

#### 产品场景特征清单

```
📌 产品特征锁定清单
├── 基本信息
│   ├── 产品类型：[具体产品名称]
│   ├── 品牌标识：[logo位置和大小]
│   └── 尺寸比例：[长宽高比例]
├── 外观特征
│   ├── 形态：[形状描述]
│   ├── 颜色：[主色+辅色]
│   ├── 材质：[金属/塑料/玻璃/布料等]
│   └── 质感：[光滑/粗糙/透明/半透明]
├── 细节特征
│   ├── 表面纹理：[具体描述]
│   ├── 高光位置：[描述反光区域]
│   ├── 透明度：[透明区域描述]
│   └── 功能部件：[按钮/接口/屏幕等]
├── 摆放姿态
│   ├── 角度：[正面/侧面/俯视/仰视]
│   ├── 倾斜：[是否倾斜及角度]
│   └── 朝向：[面向方向]
└── 画面位置
    ├── 产品在画面中的位置
    └── 产品占比
```

#### 场景背景特征清单

```
📌 场景特征锁定清单
├── 空间结构
│   ├── 纵深：[近景/中景/远景元素]
│   ├── 透视：[一点透视/两点透视等]
│   └── 空间关系：[前后左右元素关系]
├── 背景元素
│   ├── 主要物体：[位置+形态+颜色]
│   ├── 次要物体：[位置+形态+颜色]
│   └── 装饰元素：[具体描述]
├── 环境特征
│   ├── 地面：[材质+颜色]
│   ├── 墙面：[材质+颜色+纹理]
│   └── 天花板：[如有]
└── 光影基础（可改变部分）
    ├── 主光方向：[描述]
    ├── 阴影位置：[描述]
    └── 环境光色调：[描述]
```

---

## 分辨率保持规范

### 各平台分辨率声明格式

| 平台 | 分辨率声明格式 | 权重强化 |
|------|---------------|---------|
| **Midjourney** | `MUST maintain original resolution: [WIDTH]x[HEIGHT] pixels. Keep exact resolution, no upscaling or downscaling.` | 最高优先级 |
| **即梦AI** | `严格保持原图分辨率[宽]×[高]不变，绝对禁止降低分辨率。` | 最高优先级 |
| **可灵AI** | `保持原图分辨率[宽]×[高]，禁止降低分辨率，禁止模糊处理。` | 最高优先级 |
| **NanoBanana** | `(Keep original resolution [WIDTH]x[HEIGHT]:2.0), (No resolution change:1.8), (No downscaling:1.8)` | 权重强化 |

---

## 主体一致性强化

### 核心策略：三重锁定机制

#### 第一重：声明锁定（放在提示词最前面）
```
[分辨率声明]
[主体绝对一致声明]
```

#### 第二重：特征详细描述（逐项描述主体）
```
[主体特征逐项详细描述]
```

#### 第三重：负面约束锁定（全面禁止变异）
```
[负面约束清单]
```

### 各平台主体保持声明格式（强化版）

| 平台 | 主体保持声明格式（强化版） |
|------|--------------------------|
| **Midjourney** | `CRITICAL: MUST strictly maintain character's appearance, pose, clothing, expression, position EXACTLY as original. ONLY change lighting. NO face change, NO pose change, NO clothing change, NO expression change.` |
| **即梦AI** | `【绝对要求】严格保持原图人物的外貌、姿态、服装、表情、位置、背景结构完全不变，仅改变光影效果。禁止改变任何主体特征。` |
| **可灵AI** | `【强制锁定】主体完全一致：人物外貌、姿态、服装、表情、位置、背景结构严格保持不变。仅允许改变光影。任何主体变异均为失败。` |
| **NanoBanana** | `(Keep character exactly same:2.0), (Keep pose unchanged:1.8), (Keep clothing unchanged:1.8), (Keep expression unchanged:1.8), (Keep face unchanged:2.0), (Keep position unchanged:1.5)` |

### 完整负面约束清单（必须全部包含）

#### Midjourney 负面约束
```
--no resolution change, different face, different pose, different clothing, different expression, different hairstyle, different body type, different age, different gender, different position, different background, blurry, downscaling, deformed, distorted, altered features
```

#### 即梦AI 负面约束
```
禁止：降低分辨率、改变人物外貌、改变脸型、改变五官、改变发型、改变体型、改变姿态、改变服装、改变表情、改变位置、改变背景结构、模糊处理、变形、失真、AI痕迹
```

#### 可灵AI 负面约束
```
禁止：降低分辨率、改变主体、改变人物外貌、改变脸型、改变五官、改变发型、改变姿态、改变服装、改变表情、改变位置、改变背景、模糊处理、变形、失真、AI痕迹、塑料质感
```

#### NanoBanana 负面约束
```
--no resolution change, different face, different pose, different clothing, different expression, different hairstyle, different body, different position, different background, blurry, deformed, distorted, altered, plastic skin, 3d render
```

---

## Midjourney格式

### 完整结构（强化版）
```
[分辨率声明 - 最高优先级]

[主体绝对一致声明 - 强化版]

[主体特征详细描述 - 逐项描述]

ONLY change lighting: [光影改造描述]

[胶片/镜头/质感描述]

--ar [宽高比] --iw 3.0 --style raw --v 6.0
--no [完整负面约束清单]
```

### 关键参数（优化版）
| 参数 | 推荐值 | 说明 |
|------|--------|------|
| `--ar` | 原图比例 | 宽高比（如 16:9, 1:1, 2.39:1） |
| `--iw` | **3.0** | **最高权重参考原图** |
| `--style` | raw | 禁用默认审美 |
| `--v` | 6.0 | 使用V6版本 |

### 完整示例（强化版）
```
MUST maintain original resolution: 1920x1080 pixels.
Keep exact resolution, no upscaling or downscaling.

CRITICAL: MUST strictly maintain character's appearance, pose, clothing, expression, position EXACTLY as original. ONLY change lighting. NO face change, NO pose change, NO clothing change, NO expression change.

Character details (LOCKED):
- Age: approximately 25 years old female
- Face: oval face shape, fair skin, no visible blemishes
- Hair: long black hair, straight, shoulder-length, natural fall
- Eyes: big eyes, double eyelids, black pupils, looking toward right side
- Eyebrows: thin, natural arch
- Nose: high nose bridge, small nose tip
- Lips: thin lips, natural pink, slight smile
- Body: slim figure, standing straight
- Pose: frontal standing, body facing camera, head slightly tilted 15 degrees to right
- Hands: natural drop on both sides
- Clothing: white cotton dress, sleeveless, knee-length, simple design
- Expression: gentle smile, corners of mouth slightly raised, soft gaze
- Position: centered in frame, half-body portrait

ONLY change lighting: Rembrandt lighting from top-left at 45 degrees, soft key light with intensity 60%, cold blue rim light from behind at 40%, low key contrast, volumetric lighting, smoky atmosphere.

Shot on film, Kodak Vision3 500T, film grain, realistic skin texture.

--ar 16:9 --iw 3.0 --style raw --v 6.0
--no resolution change, different face, different pose, different clothing, different expression, different hairstyle, different body type, different age, different position, different background, blurry, downscaling, deformed, distorted, altered features
```

---

## 即梦AI格式

### 完整结构（强化版）
```
[分辨率声明 - 最高优先级]

[主体绝对一致声明 - 强化版]

【人物特征锁定清单】（必须保留，绝对不变）：
- 基本信息：[年龄+性别+体型]
- 头部特征：[发型+脸型+肤色]
- 五官细节：[眉毛+眼睛+鼻子+嘴唇+特征标记]
- 姿态动作：[身体朝向+头部角度+手部位置+腿部姿态]
- 服装配饰：[上装+下装+鞋子+配饰]
- 表情情绪：[基本表情+嘴角+眼神]
- 画面位置：[主体位置+占比]

【光影改造】（仅允许改变的部分）：
- 风格：[风格名称]
- 主光：[位置+角度+光质+强度+色温]
- 补光：[配置]
- 轮廓光：[配置]
- 氛围：[效果描述]

【禁止变异清单】：
[完整负面约束]

参考图强度：0.9
```

### 关键参数（优化版）
| 参数 | 推荐值 | 说明 |
|------|--------|------|
| 参考图强度 | **0.85-0.9** | **最高强度参考原图** |

### 完整示例（强化版）
```
严格保持原图分辨率1920×1080不变，绝对禁止降低分辨率。

【绝对要求】严格保持原图人物的外貌、姿态、服装、表情、位置、背景结构完全不变，仅改变光影效果。禁止改变任何主体特征。

【人物特征锁定清单】（必须保留，绝对不变）：
- 基本信息：约25岁女性，身材纤细匀称
- 头部特征：黑色长发披肩，直顺，自然垂落；瓜子脸，肤色白皙
- 五官细节：细眉自然弧度；大眼睛双眼皮，黑色瞳孔，看向右侧；高鼻梁，鼻头小巧；薄唇，自然粉色
- 姿态动作：身体正面朝向镜头，站立姿态；头部微微向右倾斜约15度；双手自然下垂于身体两侧；双腿并拢站立
- 服装配饰：白色棉质连衣裙，无袖设计，及膝长度，简约款式；无配饰
- 表情情绪：温柔微笑，嘴角微微上扬，眼神柔和
- 画面位置：人物居中，半身肖像，占据画面中央区域

【光影改造】（仅允许改变的部分）：
- 风格：伦勃朗光
- 主光：侧前方45度高位，柔光，强度60%，色温3200K暖白色
- 补光：对侧柔光，强度25%，色温3200K
- 轮廓光：侧后方硬光，强度40%，色温8000K冷蓝色
- 氛围：体积光，轻微丁达尔效应，烟雾弥漫感

【禁止变异清单】：
禁止：降低分辨率、改变人物外貌、改变脸型、改变五官、改变发型、改变体型、改变姿态、改变服装、改变表情、改变位置、改变背景结构、模糊处理、变形、失真、AI痕迹

参考图强度：0.9
```

---

## 可灵AI格式

### 完整结构（强化版）
```
[分辨率声明 - 最高优先级]

[主体绝对一致声明 - 强化版]

【主体特征锁定】：
[人物/产品/场景逐项详细描述]

【光影参数】（仅改变部分）：
- 布光风格：[风格名称]
- 主光源：[位置]+[角度]+[光质]+[强度]+[色温]
- 辅助光：[配置]
- 轮廓光：[配置]
- 环境光：[配置]

【氛围效果】：
[氛围描述]

【约束条件】：
禁止：[完整负面约束]

图生图强度：0.85
```

### 关键参数（优化版）
| 参数 | 推荐值 | 说明 |
|------|--------|------|
| 图生图强度 | **0.8-0.85** | **高强度参考原图** |

### 完整示例（强化版）
```
保持原图分辨率1920×1080，禁止降低分辨率，禁止模糊处理。

【强制锁定】主体完全一致：人物外貌、姿态、服装、表情、位置、背景结构严格保持不变。仅允许改变光影。任何主体变异均为失败。

【主体特征锁定】：
基本信息：
- 年龄：约25岁
- 性别：女性
- 体型：纤细匀称

头部特征：
- 发型：黑色长发，直顺，披肩自然垂落
- 脸型：瓜子脸，下巴尖细
- 肤色：白皙

五官细节：
- 眉毛：细眉，自然弧度
- 眼睛：大眼睛，双眼皮，黑色瞳孔，眼神看向右侧
- 鼻子：高鼻梁，鼻头小巧
- 嘴唇：薄唇，自然粉色

姿态动作：
- 身体朝向：正面朝向镜头
- 站立姿态：双腿并拢站立
- 头部角度：微微向右倾斜约15度
- 手部位置：双手自然下垂于身体两侧

服装配饰：
- 上装：白色棉质连衣裙，无袖设计
- 长度：及膝
- 款式：简约
- 配饰：无

表情情绪：
- 基本表情：温柔微笑
- 嘴角：微微上扬
- 眼神：柔和

画面位置：
- 位置：居中
- 占比：半身肖像

【光影参数】（仅改变部分）：
- 布光风格：伦勃朗光
- 主光源：侧前方45度高位，柔光，强度60%，色温3200K暖白
- 辅助光：对侧柔光，强度25%，色温3200K
- 轮廓光：侧后方硬光，强度40%，色温8000K冷蓝
- 环境光：体积光，轻微丁达尔效应

【氛围效果】：
雨夜街道背景，烟雾弥漫，胶片颗粒质感，电影级调色，暖橙冷蓝对比色调。

【约束条件】：
禁止：降低分辨率、改变主体、改变人物外貌、改变脸型、改变五官、改变发型、改变姿态、改变服装、改变表情、改变位置、改变背景、模糊处理、变形、失真、AI痕迹、塑料质感

图生图强度：0.85
```

---

## NanoBanana格式

### 完整结构（强化版）
```
[分辨率声明 - 权重强化]

[主体保持声明 - 权重强化]

Character Details (LOCKED):
- Age: [age]
- Gender: [gender]
- Face: [face shape], [skin tone]
- Hair: [color], [length], [texture], [style]
- Eyes: [size], [shape], [color], [gaze direction]
- Eyebrows: [description]
- Nose: [description]
- Lips: [description]
- Body: [body type], [pose]
- Hands: [position]
- Clothing: [detailed description]
- Expression: [description]
- Position: [position in frame]

ONLY change lighting:
([风格名称]:1.3),
([光影权重描述]).

--quality 2 --style cinematic --ar [宽高比] --strength 0.3
--no [完整负面约束]
```

### 关键参数（优化版）
| 参数 | 推荐值 | 说明 |
|------|--------|------|
| `--quality` | 2 | 高质量 |
| `--style` | cinematic | 电影风格 |
| `--strength` | **0.3** | **最弱变化，最强保持原图** |

### 完整示例（强化版）
```
(Keep original resolution 1920x1080:2.0),
(No resolution change:1.8), (No downscaling:1.8),

(Keep character exactly same:2.0),
(Keep face unchanged:2.0), (Keep pose unchanged:1.8),
(Keep clothing unchanged:1.8), (Keep expression unchanged:1.8),
(Keep position unchanged:1.5), (Keep body unchanged:1.8),

Character Details (LOCKED):
- Age: approximately 25 years old
- Gender: female
- Face: (oval face:1.5), fair skin
- Hair: (long black hair:1.8), straight, shoulder-length, natural fall
- Eyes: (big eyes:1.5), double eyelids, black pupils, (looking at right:1.3)
- Eyebrows: thin, natural arch
- Nose: high nose bridge, small tip
- Lips: thin, natural pink
- Body: slim figure, standing straight
- Pose: frontal standing, body facing camera, head tilted 15 degrees right
- Hands: natural drop on sides
- Clothing: (white cotton dress:1.5), sleeveless, knee-length
- Expression: (gentle smile:1.3), soft gaze
- Position: centered, half-body portrait

ONLY change lighting:
(Rembrandt lighting style:1.3),
(side light from top-left 45 degrees:1.2), (soft light quality:1.1),
(cold blue rim light from behind:1.3), (low key contrast:1.2),
(volumetric lighting:1.2), (smoky atmosphere:1.1),
(film grain texture:1.2), (realistic skin texture:1.1).

--quality 2 --style cinematic --ar 16:9 --strength 0.3
--no resolution change, different face, different pose, different clothing, different expression, different hairstyle, different body, different position, different background, blurry, deformed, distorted, altered, plastic skin, 3d render
```

---

## 完整提示词模板

### 四平台提示词输出模板

每次重打光任务完成后，必须按以下格式同时输出四个平台的提示词：

```markdown
📐 **原图信息**
- 分辨率：[宽] × [高]
- 主体类型：[人像/产品/场景]

🔒 **主体特征锁定清单**
- [逐项列出主体特征]

🎬 **目标光影设计**
- 风格：[风格名称]
- 主光：[位置+角度+光质+强度+色温]
- 补光：[配置]
- 轮廓光：[配置]
- 氛围：[效果]

📝 **四平台图生图提示词**

---

### 1️⃣ Midjourney 提示词

```
MUST maintain original resolution: [WIDTH]x[HEIGHT] pixels.
Keep exact resolution, no upscaling or downscaling.

CRITICAL: MUST strictly maintain character's appearance, pose, clothing, expression, position EXACTLY as original. ONLY change lighting.

Character details (LOCKED):
[主体特征逐项描述]

ONLY change lighting: [光影描述]

--ar [宽:高] --iw 3.0 --style raw --v 6.0
--no resolution change, different face, different pose, different clothing, different expression, different hairstyle, different body type, different position, blurry, deformed, distorted, altered features
```

---

### 2️⃣ 即梦AI 提示词

```
严格保持原图分辨率[宽]×[高]不变，绝对禁止降低分辨率。

【绝对要求】严格保持原图人物的外貌、姿态、服装、表情、位置、背景结构完全不变，仅改变光影效果。

【人物特征锁定清单】（必须保留，绝对不变）：
[主体特征逐项描述]

【光影改造】（仅允许改变的部分）：
- 风格：[风格名称]
- 主光：[配置]
- 补光：[配置]
- 轮廓光：[配置]

【禁止变异清单】：
禁止：降低分辨率、改变人物外貌、改变脸型、改变五官、改变发型、改变体型、改变姿态、改变服装、改变表情、改变位置、改变背景结构、模糊处理、变形、失真、AI痕迹

参考图强度：0.9
```

---

### 3️⃣ 可灵AI 提示词

```
保持原图分辨率[宽]×[高]，禁止降低分辨率，禁止模糊处理。

【强制锁定】主体完全一致：人物外貌、姿态、服装、表情、位置、背景结构严格保持不变。仅允许改变光影。

【主体特征锁定】：
[主体特征逐项描述]

【光影参数】（仅改变部分）：
- 布光风格：[风格名称]
- 主光源：[配置]
- 辅助光：[配置]
- 轮廓光：[配置]

【约束条件】：
禁止：降低分辨率、改变主体、改变人物外貌、改变脸型、改变五官、改变发型、改变姿态、改变服装、改变表情、改变位置、模糊处理、变形、失真、AI痕迹

图生图强度：0.85
```

---

### 4️⃣ NanoBanana 提示词

```
(Keep original resolution [WIDTH]x[HEIGHT]:2.0),
(No resolution change:1.8), (No downscaling:1.8),

(Keep character exactly same:2.0),
(Keep face unchanged:2.0), (Keep pose unchanged:1.8),
(Keep clothing unchanged:1.8), (Keep expression unchanged:1.8),

Character Details (LOCKED):
[主体特征权重描述]

ONLY change lighting:
([风格名称]:1.3),
([光影权重描述]).

--quality 2 --style cinematic --ar [宽:高] --strength 0.3
--no resolution change, different face, different pose, different clothing, different expression, different hairstyle, different body, blurry, deformed, distorted, altered
```
```

---

## 防变异技巧

### 技巧一：三重锁定机制
```
第一重：声明锁定（放在提示词最前面）
第二重：特征详细描述（逐项描述主体）
第三重：负面约束锁定（全面禁止变异）
```

### 技巧二：特征描述具体化
- ❌ "保持人物不变"
- ✅ "保持：约25岁女性，黑色长发直顺披肩，瓜子脸，大眼睛双眼皮看向右侧，高鼻梁，薄唇自然粉色，站立姿态正面朝向镜头，头部微右倾15度，双手自然下垂，身穿白色棉质无袖连衣裙及膝长度，温柔微笑"

### 技巧三：平台参数最优化

| 平台 | 关键参数 | 推荐值 | 说明 |
|------|---------|--------|------|
| Midjourney | `--iw` | **3.0** | **最高权重参考原图** |
| 即梦AI | 参考图强度 | **0.85-0.9** | **最高强度参考** |
| 可灵AI | 图生图强度 | **0.8-0.85** | **高强度参考** |
| NanoBanana | `--strength` | **0.3** | **最弱变化，最强保持** |

### 技巧四：权重强化（NanoBanana专用）
```
(Keep character exactly same:2.0)      // 最高权重
(Keep face unchanged:2.0)              // 面部单独锁定
(Keep pose unchanged:1.8)              // 姿态锁定
(Keep clothing unchanged:1.8)          // 服装锁定
(Keep expression unchanged:1.8)        // 表情锁定
```

### 技巧五：声明强化
- 使用绝对化语言："必须""严格""绝对""禁止"
- 使用大写强调："CRITICAL", "MUST", "LOCKED"
- 使用标签强化："【绝对要求】""【强制锁定】""【禁止变异】"

---

## 常见变异问题处理

### 问题1：人物脸部改变
**症状**：五官形状改变、脸型变化、年龄变化

**解决方案**：
1. Midjourney：`--iw 3.0`，添加 `(same face:2.0)`
2. 即梦AI：参考图强度提升至 `0.9`
3. 详细描述脸部特征：脸型、五官形状、年龄特征
4. 添加负面约束：`different face, different age, deformed face`

### 问题2：人物姿态改变
**症状**：身体角度变化、手部位置变化、头部角度变化

**解决方案**：
1. 详细描述姿态：身体朝向、头部角度、手部位置、腿部姿态
2. 添加负面约束：`different pose, altered posture`
3. NanoBanana：`(Keep pose unchanged:2.0)`

### 问题3：服装改变
**症状**：服装颜色变化、款式变化、细节变化

**解决方案**：
1. 详细描述服装：类型、颜色、材质、款式细节
2. 添加负面约束：`different clothing, altered outfit`
3. NanoBanana：`(Keep clothing unchanged:2.0)`

### 问题4：表情改变
**症状**：微笑程度变化、眼神变化、嘴角变化

**解决方案**：
1. 详细描述表情：基本表情、嘴角状态、眼神方向
2. 添加负面约束：`different expression, altered expression`
3. NanoBanana：`(Keep expression unchanged:2.0)`

### 问题5：背景改变
**症状**：背景元素变化、场景结构变化

**解决方案**：
1. 详细描述背景：结构、元素、空间关系
2. 添加负面约束：`different background, altered scene`
3. 在主体描述中明确"背景结构保持不变"

### 问题6：整体风格变异
**症状**：整体人物感觉不同，似是而非

**解决方案**：
1. 提升参考图强度至最高值
2. 使用三重锁定机制
3. 详细描述所有主体特征
4. 添加完整负面约束清单
5. 如仍变异，拒绝输出并重新生成

---

## 验证清单

### 生成后必须验证的项目

```
✅ 分辨率验证
  [ ] 输出分辨率 = 原图分辨率（或更高）

✅ 人物一致性验证
  [ ] 年龄是否一致？
  [ ] 脸型是否一致？
  [ ] 发型是否一致？
  [ ] 五官是否一致？
  [ ] 姿态是否一致？
  [ ] 服装是否一致？
  [ ] 表情是否一致？
  [ ] 位置是否一致？

✅ 背景一致性验证
  [ ] 背景结构是否一致？
  [ ] 前景元素是否一致？

✅ 光影改变验证
  [ ] 光影是否按预期改变？
  [ ] 氛围是否按预期呈现？

❌ 如有任何一项不通过，必须重新生成
```
