---
name: photo-rescue-platform
description: wan2.7模型能力说明，涵盖阿里云百炼平台支持的图像生成和编辑能力；包含模型特性、API规格、使用限制；智能体参考此文档选择合适的wan2.7能力
---

# platform-guide.md · 平台能力说明

## 模型信息

| 项目 | 值 |
|------|-----|
| **模型名称** | wanx-v1 (wan2.7) |
| **平台** | 阿里云百炼 (DashScope) |
| **API地址** | dashscope.aliyuncs.com |

## 支持能力

### 1. 文生图 (Text-to-Image)

**端点**：
```
POST https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis
```

**适用场景**：
- 创意图片生成
- 背景重建
- 氛围图片创建

**参数**：
```json
{
  "model": "wanx-v1",
  "input": {
    "prompt": "文本描述"
  },
  "parameters": {
    "size": "1024*1024",
    "n": 1,
    "style": "<auto>"
  }
}
```

---

### 2. 图生图 (Image-to-Image)

**端点**：
```
POST https://dashscope.aliyuncs.com/api/v1/services/aigc/image2image/image-synthesis
```

**适用场景**：
- 废片修复（核心能力）
- 局部修改
- 风格转换

**参数**：
```json
{
  "model": "wanx-v1",
  "input": {
    "image": "base64编码图片",
    "prompt": "修改描述"
  },
  "parameters": {
    "strength": 0.7,
    "n": 1
  }
}
```

---

## strength 参数说明

| 值 | 效果 | 适用场景 |
|------|------|----------|
| 0.3-0.5 | 轻微调整 | 保留原图细节，微调 |
| 0.5-0.7 | 中等调整 | 平衡效果与一致性 |
| 0.7-1.0 | 大幅修改 | 更接近目标描述 |

## 异步任务

### 提交任务
```json
{
  "output": {
    "task_id": "xxx"
  }
}
```

### 查询状态
```
GET https://dashscope.aliyuncs.com/api/v1/tasks/{task_id}
```

**状态值**：
- `PENDING`：等待中
- `RUNNING`：处理中
- `SUCCEEDED`：成功
- `FAILED`：失败

---

## 使用限制

| 限制项 | 值 |
|--------|-----|
| **输入图片大小** | ≤5MB（建议） |
| **输入图片尺寸** | ≤2048px（建议） |
| **任务超时** | 300秒 |
| **轮询间隔** | 3秒 |

## 自动压缩策略

当图片超出限制时，自动执行：

1. **尺寸压缩**：超过2048px时等比缩放
2. **质量压缩**：超过5MB时逐步降低质量（95→50）
3. **格式转换**：自动转为JPEG

---

## 常见错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| `图片大小超限` | 超过5MB | 自动压缩或提示用户 |
| `图片尺寸超限` | 超过2048px | 自动缩放 |
| `任务超时` | 处理时间过长 | 等待或重试 |
| `API配额用尽` | 请求频率过高 | 切换API Key |

---

## 认证方式

```python
headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json",
    "X-DashScope-Async": "enable"
}
```

**注意**：所有请求需要携带有效的 API Key
