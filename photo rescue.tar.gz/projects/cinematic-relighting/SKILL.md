---
name: cinematic-relighting
description: 专用于图生图（img2img）场景，在严格保持原图人物、角色、构图不变的前提下，进行专业电影级的补光、光影重构与氛围调整。适用于即梦AI、豆包、NanoBanana、Midjourney V6、Stable Diffusion XL等AI绘图引擎。
dependency:
  python:
    - Pillow>=10.0.0
    - numpy>=1.24.0
    - opencv-python>=4.8.0
---

# 电影级光影重构架构师

## 任务目标
- 本Skill用于：在严格保持原图内容不变的前提下，对图像进行专业电影级的光影重构
- 能力包含：
  1. 逆向视觉解析：提取原图的内容层与光影层
  2. 目标光影设计：基于专业布光知识库设计新光影方案
  3. 结构化提示词生成：生成适配即梦AI/豆包/NanoBanana等平台的提示词
  4. 图像生成：使用智能体能力直接生成光影调整后的图片
- 触发条件：用户提出"改光影"、"重新打光"、"增加氛围"等图生图需求

## 前置准备
- 确保已安装Python依赖：
  ```bash
  pip install Pillow numpy opencv-python
  ```

## 操作步骤

### 阶段一：逆向视觉解析

1. **调用图像分析脚本**
   - 执行 `python scripts/image_analysis.py --image <image_path>` 提取原图特征
   - 获取内容包括：画面主体描述、当前光源特征、构图信息、色调氛围

2. **内容冻结锚点识别**
   - 基于分析结果，明确必须冻结的核心元素：
     - 人物：面部特征、发型、服装细节、姿态
     - 环境：背景物体位置、场景结构
     - 构图：镜头角度、景深范围

3. **原光影剥离**
   - 记录原图当前的光影状态：
     - 光源方向（顶光/侧光/平光等）
     - 光源硬度（硬光/柔光）
     - 色温（暖色/冷色/中性）
     - 对比度级别

### 阶段二：目标光影设计

1. **光影基调定义**
   - 根据用户需求确定目标氛围（悬疑/浪漫/压抑/温暖等）
   - 参考 [references/lighting-guide.md](references/lighting-guide.md) 选择合适的光影风格

2. **布光方案设计**
   - 主光选择：Rembrandt光、侧光、蝴蝶光、顶光等
   - 修饰光添加：轮廓光(Rim Light)、眼神光、体积光
   - 光质设定：硬光/柔光/明暗对照法
   - 质感注入：胶片颗粒、皮肤纹理、镜头效果

3. **物理逻辑验证**
   - 检查新增光源方向是否合理
   - 确认阴影方向与主光一致
   - 验证色温搭配是否符合物理规律

### 阶段三：结构化指令生成

1. **生成结构化提示词**
   - 根据用户需求和目标平台选择输出格式：
     - **JSON格式（推荐，专业级）**：结构化数据，强制AI区分主体与光影
     - **自然语言格式（简化版）**：适配即梦AI/豆包/NanoBanana，降低失败率
   - 即梦AI/豆包格式：自然语言描述，简洁清晰，优先保证内容一致性
   - NanoBanana格式：可包含结构化参数和权重控制

2. **JSON格式生成（专业级）**
   - 必须输出标准的JSON格式，包含以下字段：
     - `instructions`: 任务指令和内容冻结协议
     - `prompt_construction`: 主体锚点 + 新光影场景 + 电影质感
     - `parameters`: 主光、轮廓光、氛围等参数
     - `negative_prompt`: 负面提示词
   - **关键原则**：
     - 使用最高权重强调内容锚点
     - 语法上分离主体描述与光影描述
     - 明确指定负面提示词

3. **自然语言格式生成（简化版，降低失败率）**
   - **降低失败率的关键原则**：
     - **第一优先级**：内容冻结 - 使用最直接、最强烈的语言强调内容不变
     - **第二优先级**：光影调整 - 使用简单易懂的描述，避免过于专业的术语
     - **第三优先级**：质感提升 - 适度添加质感描述，避免过度复杂
     - **负面约束**：明确列出所有禁止改变的内容，重复强调

4. **质量控制检查**
   - 内容一致性：检查提示词是否足够强调"不改变内容"
   - 光影逻辑性：确认光影描述清晰易懂，无矛盾
   - 质感真实性：质感描述适度，不干扰主体保持
   - **失败率自检**：提示词是否过于复杂？是否容易被误解？

5. **输出交付**
   - 提供适配目标平台的完整提示词
   - **JSON格式**：包含完整结构化数据
   - **自然语言格式**：提供"简化版"和"详细版"两种选项
   - 附带关键参数说明（主光类型、轮廓光颜色、胶片类型等）
   - 参考 [references/lighting-guide.md](references/lighting-guide.md) 中的平台格式说明

### 阶段四：图像生成

1. **智能体生成图像**
   - 使用智能体自身的图像生成能力（图生图）
   - 基于阶段一生成的图像分析结果
   - 使用阶段三生成的提示词（JSON或自然语言格式）
   - 严格遵循内容冻结协议，确保原图内容不变

2. **生成参数设置**
   - 输入：原始图像
   - 提示词：使用阶段三生成的提示词
   - 负面提示词：包含在JSON或自然语言格式中
   - 生成强度：建议设置为中等（0.5-0.7），确保内容保持

3. **输出结果**
   - 生成的图像：光影调整后的图片
   - 提示词：使用的提示词（JSON或自然语言格式）
   - 关键参数说明：主光类型、轮廓光颜色、胶片类型等

4. **质量检查**
   - 内容一致性：确认人物、服装、背景未被改变
   - 光影效果：确认光影调整符合设计要求
   - 整体质量：检查是否有明显的AI痕迹或不自然的地方

### 阶段四：图像生成

1. **智能体生成图像**
   - 使用智能体自身的图像生成能力（图生图）
   - 基于阶段一生成的图像分析结果
   - 使用阶段三生成的提示词（JSON或自然语言格式）
   - 严格遵循内容冻结协议，确保原图内容不变

2. **生成参数设置**
   - 输入：原始图像
   - 提示词：使用阶段三生成的提示词
   - 负面提示词：包含在JSON或自然语言格式中
   - 生成强度：建议设置为中等（0.5-0.7），确保内容保持

3. **输出结果**
   - 生成的图像：光影调整后的图片
   - 提示词：使用的提示词（JSON或自然语言格式）
   - 关键参数说明：主光类型、轮廓光颜色、胶片类型等

4. **质量检查**
   - 内容一致性：确认人物、服装、背景未被改变
   - 光影效果：确认光影调整符合设计要求
   - 整体质量：检查是否有明显的AI痕迹或不自然的地方

## 资源索引
- 必要脚本：见 [scripts/image_analysis.py](scripts/image_analysis.py)（图像分析与光影特征提取）
- 领域参考：见 [references/lighting-guide.md](references/lighting-guide.md)（专业布光知识库与风格定义）
- 输出资产：
  - JSON格式提示词（专业级，结构化输出）
  - 自然语言提示词（简化版，适配即梦AI、豆包、NanoBanana等）
  - 光影调整后的图像（使用智能体图生图能力生成）

## 注意事项
- **内容冻结协议（最高优先级）**：所有改动仅限于光线如何照亮物体，不能改变物体本身。必须使用最强烈的语言反复强调
- **图像生成方式**：使用智能体自身的图生图能力，不需要调用外部API
- **光影分离原则**：在提示词中，主体描述与光影描述必须在语法上分离，避免语义混合
- **降低失败率的技巧**：
  - 提示词越简单越可靠，避免堆砌过多专业术语
  - 优先保证"不改变内容"，其次才是"优化光影"
  - 负面提示词要详细、具体、重复强调
  - 对于即梦AI/豆包等平台，使用更自然、口语化的表达
  - 对于复杂光影需求，建议分步调整而非一次性完成
  - 生成强度建议设置为中等（0.5-0.7），确保内容保持
- **物理真实性**：光影设计必须符合物理规律，不能出现矛盾的光源方向
- **质感优先**：必须包含胶片颗粒、皮肤纹理等质感描述，避免AI塑料感，但要适度
- **平台适配**：根据目标平台（即梦AI/豆包/NanoBanana）调整提示词格式和表达方式

### 示例1：赛博朋克夜景重构
**功能**：将平淡照片改为赛博朋克霓虹夜景
**执行方式**：脚本分析 + 智能体设计

**JSON格式输出（专业级）**：
```json
{
  "instructions": {
    "task": "Image-to-Image Relighting",
    "primary_directive": "CRITICAL: KEEP ORIGINAL IMAGE CONTENT, CHARACTER, AND COMPOSITION EXACTLY THE SAME. ONLY CHANGE LIGHTING.",
    "reference_image_usage": "High influence on structure/content, low influence on lighting."
  },
  "prompt_construction": {
    "subject_anchor": "红发女性，黑色皮夹克，站在赛博朋克街道中央::2",
    "new_lighting_scenario": "在保持原图主体不变的基础上，场景被重新照亮。蓝色霓虹侧光从右上方45度照射，创造出赛博朋克科幻氛围。一道明显的粉红色轮廓光 (Rim Light) 勾勒出主体边缘，烟雾弥漫的雨夜效果。",
    "cinematic_texture": "Shot on film, Kodak Vision3 500T, heavy film grain, realistic skin texture, subsurface scattering, detailed shadows, cyberpunk aesthetic."
  },
  "parameters": {
    "key_light": "Blue neon side light at 45-degree angle",
    "rim_light": "Pink neon rim light",
    "atmosphere": "Smoky, rainy night, cyberpunk",
    "aspect_ratio": "Keep original aspect ratio"
  },
  "negative_prompt": "Changing character face, changing clothes, changing background structure, distorted features, plastic skin, 3d render, flat lighting, overexposed, cartoonish."
}
```

**自然语言格式 - 简化版（适配即梦AI/豆包，推荐，成功率更高）**：
```
保持原图所有内容完全不变，只改变光线。蓝色侧光从右侧照射，粉色边缘光，雨夜烟雾效果。不要改变人物、服装、背景。
```

**自然语言格式 - 详细版（适配即梦AI/豆包）**：
```
保持原图中红发女性、黑色皮夹克、站在街道中央的所有细节不变。重新布光：蓝色霓虹侧光从右上方45度照射，粉红色轮廓光勾勒人物边缘。烟雾弥漫、雨夜、丁达尔效应、电影级质感。不要改变人物面部、服装、背景结构，不要改变人物特征。
```

### 示例2：黑色电影风格转化
**功能**：用顶光制造悬疑压抑感
**执行方式**：智能体主导设计

**JSON格式输出（专业级）**：
```json
{
  "instructions": {
    "task": "Image-to-Image Relighting",
    "primary_directive": "CRITICAL: KEEP ORIGINAL IMAGE CONTENT, CHARACTER, AND COMPOSITION EXACTLY THE SAME. ONLY CHANGE LIGHTING.",
    "reference_image_usage": "High influence on structure/content, low influence on lighting."
  },
  "prompt_construction": {
    "subject_anchor": "原图人物和场景::2",
    "new_lighting_scenario": "在保持原图内容不变的基础上，场景被重新照亮。Top-down Noir Lighting顶光从正上方垂直照射，创造出强烈的黑色电影悬疑氛围。极高对比度的Chiaroscuro明暗对照法。",
    "cinematic_texture": "Shot on film, anamorphic lens, heavy film grain, dramatic shadows, noir aesthetic, cinematic lighting."
  },
  "parameters": {
    "key_light": "Top-down Noir Lighting",
    "rim_light": "Subtle cool rim light",
    "atmosphere": "Mysterious,压抑, film noir",
    "aspect_ratio": "Keep original aspect ratio"
  },
  "negative_prompt": "Changing character face, changing clothes, changing background structure, distorted features, plastic skin, 3d render, flat lighting, overexposed, cartoonish."
}
```

**自然语言格式 - 简化版（适配即梦AI/豆包，推荐，成功率更高）**：
```
保持原图所有内容不变，只调整光线。顶光照射，高对比度，黑色电影风格，强烈阴影。不要改变人物、服装、背景。
```

**自然语言格式 - 详细版（适配即梦AI/豆包）**：
```
保持原图内容和构图完全不变。Top-down Noir Lighting，强烈的顶光投影，Chiaroscuro明暗对照法，极高对比度。变形宽银幕镜头，椭圆焦外，Kodak Vision3 500T胶片，粗颗粒。避免改变人物、改变背景、3D渲染感、平面光线。
```

### 示例3：唯美夕阳氛围
**功能**：添加金色夕阳轮廓光
**执行方式**：脚本分析 + 智能体设计

**JSON格式输出（专业级）**：
```json
{
  "instructions": {
    "task": "Image-to-Image Relighting",
    "primary_directive": "CRITICAL: KEEP ORIGINAL IMAGE CONTENT, CHARACTER, AND COMPOSITION EXACTLY THE SAME. ONLY CHANGE LIGHTING.",
    "reference_image_usage": "High influence on structure/content, low influence on lighting."
  },
  "prompt_construction": {
    "subject_anchor": "原图人物和环境::2",
    "new_lighting_scenario": "在保持原图内容不变的基础上，场景被重新照亮。暖金色侧逆光从后方照射，创造出唯美温暖的夕阳氛围。一道强烈的金色轮廓光 (Rim Light) 勾勒出主体边缘。",
    "cinematic_texture": "Shot on film, Kodak Portra 400, visible pores, subsurface scattering, warm golden hour glow, soft focus."
  },
  "parameters": {
    "key_light": "Warm golden backlight",
    "rim_light": "Golden rim light",
    "atmosphere": "Warm, romantic, golden hour",
    "aspect_ratio": "Keep original aspect ratio"
  },
  "negative_prompt": "Changing character face, changing clothes, changing background structure, distorted features, plastic skin, 3d render, flat lighting, overexposed, cartoonish."
}
```

**自然语言格式 - 简化版（适配即梦AI/豆包，推荐，成功率更高）**：
```
保持原图人物和环境完全不变，只改变光线。金色夕阳从后方照射，暖色调边缘光，柔光效果，温暖氛围。不要改变人物、服装、背景。
```

**自然语言格式 - 详细版（适配即梦AI/豆包）**：
```
保持原图人物和环境不变。暖金色侧逆光，强烈的边缘光，Subsurface Scattering 3S透光，可见毛孔，Kodak Portra 400胶片，自然肤色。金色光晕、柔焦效果、温暖氛围。不要改变人物特征、改变服装、AI塑料感。
```

### NanoBanana平台专用示例
**功能**：使用结构化参数和权重控制

**提示词示例**：
```
(保持原图所有内容不变，只改变光线:1.8)，侧光照射，高对比度，电影质感。(负面: 改变人物、改变服装、改变背景、3D渲染、AI塑料感)
```

## 降低失败率的实用技巧

### 1. 分步调整策略
**适用场景**：复杂光影需求

**第一步**：只调整主光方向和颜色
```
保持所有内容不变，只改变光线。蓝色侧光从右侧照射。
```

**第二步**：添加轮廓光
```
保持所有内容不变，只改变光线。蓝色侧光从右侧照射，粉色边缘光。
```

**第三步**：添加氛围和质感
```
保持所有内容不变，只改变光线。蓝色侧光从右侧照射，粉色边缘光，雨夜烟雾效果，胶片质感。
```

### 2. 负面提示词强化技巧
**重复强调**：
- ❌ "不要改变内容"（太简单）
- ✅ "不要改变人物，不要改变服装，不要改变背景，不要改变发型"（具体列举）

**使用绝对语言**：
- ❌ "尽量不要改变"（有商量的余地）
- ✅ "保持不变，完全不变"（绝对化表达）

### 3. 简化术语使用
**优先使用通用词汇**：
- ❌ "Chiaroscuro"、"Subsurface Scattering"、"Anamorphic Lens"
- ✅ "高对比度"、"透光质感"、"宽银幕镜头"

**根据平台选择**：
- 即梦AI/豆包：使用中文通俗表达
- NanoBanana：可使用英文专业术语
- Midjourney：使用英文关键词

### 4. JSON vs 自然语言选择指南

| 目标平台 | 推荐格式 | 成功率 | 适用场景 |
|---------|---------|--------|---------|
| Stable Diffusion XL | JSON格式 | 高 | 专业用户，精细控制 |
| Midjourney V6 | JSON或自然语言 | 中-高 | 创作自由，灵活输出 |
| 即梦AI/豆包 | 自然语言简化版 | 高 | 通用场景，降低失败率 |
| NanoBanana | 自然语言+权重 | 中 | 专业用户，参数控制 |

**建议**：
- 如果平台支持JSON输入，优先使用JSON格式（结构化、精确）
- 如果追求成功率，使用自然语言简化版
- 如果追求专业效果，使用自然语言详细版 + JSON格式
