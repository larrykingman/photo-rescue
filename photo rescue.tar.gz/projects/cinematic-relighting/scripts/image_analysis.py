#!/usr/bin/env python3
"""
电影级光影重构 - 图像分析与光影特征提取工具

功能：
1. 提取图像的基本信息（尺寸、格式）
2. 分析图像的色彩分布与色调
3. 推测光源方向（基于亮度梯度）
4. 评估光影硬度（基于边缘锐度）
5. 检测画面构图特征

使用方式：
    python scripts/image_analysis.py --image <image_path>
"""

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image


def analyze_image_metadata(image_path):
    """分析图像基本元数据"""
    try:
        img = Image.open(image_path)
        return {
            "format": img.format,
            "mode": img.mode,
            "size": img.size,
            "width": img.width,
            "height": img.height,
            "aspect_ratio": round(img.width / img.height, 2)
        }
    except Exception as e:
        return {"error": f"无法读取图像元数据: {str(e)}"}


def analyze_color_distribution(image_path):
    """分析色彩分布与色调特征"""
    try:
        img = cv2.imread(str(image_path))
        if img is None:
            return {"error": "无法读取图像文件"}

        # 转换到HSV色彩空间
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        # 计算平均色相、饱和度、明度
        mean_hsv = cv2.mean(hsv)[:3]

        # 判断主色调倾向
        hue = mean_hsv[0]
        saturation = mean_hsv[1]
        value = mean_hsv[2]

        # 色温判断
        if hue < 10 or hue > 170:
            tone = "warm"  # 暖色调（红/橙/黄）
        elif 100 <= hue <= 140:
            tone = "cool"  # 冷色调（蓝/青）
        else:
            tone = "neutral"  # 中性色调

        # 对比度判断（基于标准差）
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        contrast = gray.std()

        contrast_level = "high" if contrast > 80 else "medium" if contrast > 40 else "low"

        return {
            "average_hue": round(mean_hsv[0], 1),
            "average_saturation": round(mean_hsv[1], 1),
            "average_brightness": round(mean_hsv[2], 1),
            "tone": tone,
            "contrast_level": contrast_level,
            "contrast_value": round(contrast, 1)
        }
    except Exception as e:
        return {"error": f"色彩分析失败: {str(e)}"}


def estimate_light_source(image_path):
    """推测光源方向（基于亮度梯度分析）"""
    try:
        img = cv2.imread(str(image_path))
        if img is None:
            return {"error": "无法读取图像文件"}

        # 转换为灰度图
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # 计算四个方向的亮度平均值
        h, w = gray.shape
        top = gray[:int(h/3), :].mean()
        bottom = gray[int(2*h/3):, :].mean()
        left = gray[:, :int(w/3)].mean()
        right = gray[:, int(2*w/3):].mean()
        center = gray[int(h/3):int(2*h/3), int(w/3):int(2*w/3)].mean()

        # 判断光源方向
        diffs = {
            "top": top - center,
            "bottom": bottom - center,
            "left": left - center,
            "right": right - center
        }

        # 找到最亮的方向
        max_diff = max(diffs.values())

        if max_diff < 5:
            direction = "flat"  # 平光
        elif direction := max(diffs, key=diffs.get):
            pass  # 使用最亮的方向

        # 光源硬度判断（基于边缘锐度）
        edges = cv2.Canny(gray, 50, 150)
        edge_density = np.sum(edges > 0) / (h * w)

        hardness = "hard" if edge_density > 0.02 else "soft"

        return {
            "light_direction": direction,
            "light_hardness": hardness,
            "brightness_distribution": {
                "top": round(top, 1),
                "bottom": round(bottom, 1),
                "left": round(left, 1),
                "right": round(right, 1),
                "center": round(center, 1)
            }
        }
    except Exception as e:
        return {"error": f"光源分析失败: {str(e)}"}


def detect_composition_features(image_path):
    """检测构图特征"""
    try:
        img = cv2.imread(str(image_path))
        if img is None:
            return {"error": "无法读取图像文件"}

        h, w = img.shape[:2]

        # 检测主体位置（基于亮度梯度）
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        gradient_magnitude = np.sqrt(grad_x**2 + grad_y**2)

        # 找到梯度最强区域（可能是主体）
        center_y, center_x = np.unravel_index(gradient_magnitude.argmax(), gradient_magnitude.shape)

        # 判断主体在画面中的位置
        vertical_pos = "center" if abs(center_y - h/2) < h/6 else ("top" if center_y < h/2 else "bottom")
        horizontal_pos = "center" if abs(center_x - w/2) < w/6 else ("left" if center_x < w/2 else "right")

        return {
            "subject_position": {
                "vertical": vertical_pos,
                "horizontal": horizontal_pos,
                "coordinates": {"x": int(center_x), "y": int(center_y)}
            },
            "image_aspect_ratio": f"{w}:{h}"
        }
    except Exception as e:
        return {"error": f"构图分析失败: {str(e)}"}


def generate_summary(analysis_result):
    """生成分析结果摘要（用于智能体理解）"""
    summary_parts = []

    # 元数据
    if "metadata" in analysis_result:
        meta = analysis_result["metadata"]
        if "aspect_ratio" in meta:
            summary_parts.append(f"图像比例为 {meta['aspect_ratio']}")

    # 色彩信息
    if "color" in analysis_result:
        color = analysis_result["color"]
        if "tone" in color:
            tone_map = {"warm": "暖色调", "cool": "冷色调", "neutral": "中性色调"}
            summary_parts.append(f"整体色调为{tone_map.get(color['tone'], color['tone'])}")
        if "contrast_level" in color:
            contrast_map = {"high": "高", "medium": "中", "low": "低"}
            summary_parts.append(f"对比度为{contrast_map.get(color['contrast_level'], color['contrast_level'])}")

    # 光源信息
    if "light" in analysis_result:
        light = analysis_result["light"]
        if "light_direction" in light:
            direction_map = {
                "top": "顶光",
                "bottom": "底光",
                "left": "左侧光",
                "right": "右侧光",
                "flat": "平光/漫射光"
            }
            summary_parts.append(f"当前光源方向为{direction_map.get(light['light_direction'], light['light_direction'])}")
        if "light_hardness" in light:
            hardness_map = {"hard": "硬光", "soft": "柔光"}
            summary_parts.append(f"光源硬度为{hardness_map.get(light['light_hardness'], light['light_hardness'])}")

    return "; ".join(summary_parts) if summary_parts else "图像分析数据不完整"


def main():
    parser = argparse.ArgumentParser(description="电影级光影重构 - 图像分析工具")
    parser.add_argument("--image", required=True, help="输入图像路径")
    parser.add_argument("--output", "-o", help="输出JSON文件路径（可选）")
    args = parser.parse_args()

    image_path = Path(args.image)

    if not image_path.exists():
        print(f"错误：图像文件不存在: {image_path}", file=sys.stderr)
        sys.exit(1)

    print(f"正在分析图像: {image_path}\n")

    # 执行各项分析
    analysis_result = {
        "metadata": analyze_image_metadata(image_path),
        "color": analyze_color_distribution(image_path),
        "light": estimate_light_source(image_path),
        "composition": detect_composition_features(image_path)
    }

    # 生成摘要
    summary = generate_summary(analysis_result)

    # 输出结果
    result_json = json.dumps(analysis_result, indent=2, ensure_ascii=False)

    if args.output:
        output_path = Path(args.output)
        output_path.write_text(result_json, encoding="utf-8")
        print(f"分析结果已保存至: {output_path}\n")
    else:
        print("=" * 60)
        print("分析摘要")
        print("=" * 60)
        print(summary)
        print("\n" + "=" * 60)
        print("详细分析结果")
        print("=" * 60)
        print(result_json)

    return analysis_result


if __name__ == "__main__":
    main()
