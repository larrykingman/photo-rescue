# Midjourney 提示词示例

## 示例 1：悬疑惊悚场景（侦探雨夜）

### 提示词
```
Shot on ARRI Alexa Mini with 35mm Anamorphic lens, Kodak Vision3 5219 (500T). Lit by harsh "Rembrandt Lighting" from the top-left creating deep eye shadows, contrasting with a cold blue neon "Rim Light" from behind. High contrast "Chiaroscuro" lighting. An exhausted detective smokes a cigarette, sweat on forehead ("micro-sweat"), visible pores, eyes looking off-camera. Dutch Angle composition, dirty foreground of rain-streaked glass. Smoky atmosphere, film grain. Teal and Orange color grading. --ar 2.39:1 --style raw --s 250 --no "plastic skin, smooth skin, 3d render, flat lighting, shadowless"
```

### 光影架构分析
- **主光**：Rembrandt Lighting（伦勃朗光）- 45度侧光，高位，制造深邃阴影
- **修饰光**：冷蓝色 Rim Light（轮廓光）- 从背后勾勒，增加立体感和冷暖对比
- **光质**：Hard Light（硬光）- 强调残酷、压抑感
- **对比度**：Low Key（低调）- Chiaroscuro 明暗对照法，高对比度
- **大气**：Smoky atmosphere（烟雾）- 增加氛围感和层次感

### 光学物理参数
- **摄影机**：ARRI Alexa Mini - 专业数字摄影机
- **镜头**：35mm Anamorphic - 变形宽银幕，椭圆光斑，横向拉丝炫光
- **胶片**：Kodak Vision3 5219 (500T) - 强颗粒感，色彩浓郁，夜景首选
- **构图**：Dutch Angle（荷兰倾斜）- 不安、混乱、心理不稳定
- **前景**：Dirty foreground of rain-streaked glass - 窥视感、层次感

### 微细节
- **皮肤**：sweat on forehead（微汗）、visible pores（可见毛孔）- 焦灼感、真实感
- **环境**：rain-streaked glass（雨痕玻璃）、smoky atmosphere（烟雾）- 氛围感

---

## 示例 2：浪漫爱情场景（海边日落）

### 提示词
```
Shot on Kodak Portra 400 with 85mm lens. Lit by soft "Butterfly Lighting" from high front, creating gentle shadows under nose. Warm golden "Rim Light" from side-back lighting up hair edges. High Key lighting with Tyndall Effect. A young woman with windblown hair, freckles on cheeks ("natural blemishes"), soft smile, looking at the ocean. Rule of Thirds composition, negative space to the right. Peach fuzz visible on cheek in golden hour light. Warm and romantic color grading. --ar 16:9 --style raw --s 200 --no "plastic skin, airbrushed face, 3d render, studio lighting"
```

### 光影架构分析
- **主光**：Butterfly Lighting（蝴蝶光）- 高位正面光，美化肤质
- **修饰光**：暖金色 Rim Light（轮廓光）- 从侧后方勾勒头发，增加层次
- **光质**：Soft Light（柔光）- 唯美、浪漫
- **对比度**：High Key（高调）- 明亮、快乐、纯真
- **大气**：Tyndall Effect（丁达尔效应）- 尘埃在光中飞舞，增加温暖感

### 光学物理参数
- **胶片**：Kodak Portra 400 - 肤色还原之王，温暖，日系感
- **镜头**：85mm - 长焦，压缩空间，聚焦面部情绪
- **构图**：Rule of Thirds（三分法）- 平衡、自然
- **留白**：Negative space to the right - 期待、孤独、思考空间

### 微细节
- **皮肤**：freckles on cheeks（雀斑）、peach fuzz（面部绒毛）- 自然、真实
- **环境**：windblown hair（风吹头发）- 动感、自然环境

---

## 示例 3：历史史诗场景（战场将军）

### 提示词
```
Shot on ARRI Alexa LF with 24mm lens, Kodak Vision3 5219 (500T). Lit by dramatic "Rembrandt Lighting" from side, strong "Rim Light" from back. Medium Contrast lighting with Volumetric Lighting. A battle-hardened general with deep wrinkles, scars on face ("natural blemishes"), intense gaze looking forward. Center Framing composition, epic scale, soldiers in background. Dust particles in air, weathered armor texture. Desaturated color grading with warm skin tones. --ar 2.39:1 --style raw --s 300 --no "plastic skin, smooth skin, 3d render, anime"
```

### 光影架构分析
- **主光**：Rembrandt Lighting（伦勃朗光）- 经典、深邃、权威感
- **修饰光**：强烈的 Rim Light（轮廓光）- 勾勒人物边缘，增强立体感
- **光质**：Medium Light（中等光质）- 力量感
- **对比度**：Medium Contrast（中等对比）- 平衡戏剧性和可读性
- **大气**：Volumetric Lighting（体积光）- 戏剧性、史诗感

### 光学物理参数
- **摄影机**：ARRI Alexa LF - 动态范围极高，现代电影标杆
- **镜头**：24mm 广角 - 包含环境，强调人物与场景的关系
- **胶片**：Kodak Vision3 5219 (500T) - 颗粒感，史诗质感
- **构图**：Center Framing（中心对称）- 权威、英雄感

### 微细节
- **皮肤**：deep wrinkles（深皱纹）、scars（伤疤）- 岁月感、战斗经历
- **环境**：dust particles（灰尘）、weathered armor（风化盔甲）- 战场氛围

---

## 示例 4：科幻冷峻场景（未来实验室）

### 提示词
```
Shot on ARRI Alexa LF with 35mm lens. Lit by cold "Short Lighting" from side, blue "Rim Light" from back. Low Key lighting with Haze/Fog. A scientist with subtle visible pores, neutral expression, looking at holographic display. Dutch Angle composition, negative space, futuristic laboratory background. Diffused light, cold color palette (blue and cyan). No film grain, digital pristine image. --ar 16:9 --style raw --s 150 --no "plastic skin, warm tones, vintage, film grain"
```

### 光影架构分析
- **主光**：Short Lighting（窄光）- 神秘、警惕、内敛
- **修饰光**：冷蓝色 Rim Light（轮廓光）- 科技感、未来感
- **光质**：Diffused Light（漫射光）- 冷峻、客观
- **对比度**：Low Key（低调）- 悬疑、压抑
- **大气**：Haze/Fog（雾感）- 未来感、疏离

### 光学物理参数
- **摄影机**：ARRI Alexa LF - 现代电影摄影机
- **镜头**：35mm - 平衡环境与人物
- **构图**：Dutch Angle（荷兰倾斜）- 不安、混乱
- **风格**：Digital pristine image - 纯净数字感，无胶片颗粒

### 微细节
- **皮肤**：subtle visible pores（轻微可见毛孔）- 真实但不强调
- **环境**：futuristic laboratory（未来实验室）、haze（雾感）- 科幻氛围

---

## 示例 5：图生图（保持主体一致性 - 改变光影）

### 场景描述
用户上传一张人像照片，希望将人物的普通柔光改造成电影感的伦勃朗光，同时严格保持人物的外貌、姿态、服装、表情不变。

### 提示词
```
MUST strictly maintain: Character's appearance, pose, clothing, expression from reference image.

Character: 25-year-old female with (long black hair:1.5), (oval face:1.3),
(big eyes with double eyelids:1.2), high nose bridge, thin lips,
white cotton knee-length dress, standing pose, gentle smile,
looking slightly to the right.

ONLY change lighting and atmosphere:
(Change from natural soft front light to:1.3)
Rembrandt lighting from top-left 45 degrees creating deep shadows,
(cold blue rim light from behind:1.2) to separate character from background,
(Low key Chiaroscuro contrast:1.3),
background from simple to rainy street at night with neon lights,
(volumetric lighting:1.2), (smoky atmosphere:1.1), (Tyndall effect:1.1),
enhance film grain, weathered texture, dust particles,
change color grading to teal and orange.

--ar 2.39:1 --style raw --iw 2 --v 6.0
--no different face, different pose, different clothing, different expression,
plastic skin, smooth skin, 3d render, flat lighting, shadowless
```

### 提示词结构分析
- **主体保持**（高权重）：详细描述需要保留的特征，使用 `MUST strictly maintain` 强制语言
- **光影改变**（中高权重）：明确说明从什么光改为什么光
- **环境改变**：描述背景和氛围的变化
- **参考图权重**：`--iw 2` 提高原图权重，确保主体一致性

### 参数说明
- `--iw 2`：图片权重2，确保主体高度一致
- `MUST strictly maintain`：强制保持主体不变的语言
- `(关键词:1.5)`：高权重强调重要特征
- `ONLY change`：明确只改变光影和氛围
- `--no`：负面提示词禁止改变主体

### 使用方法
1. 在 Discord 上传原图
2. 使用 `/imagine` 命令
3. 将提示词复制到输入框
4. 拖入原图作为参考
5. 设置 `--iw 2` 参数
6. 生成后检查主体一致性
7. 如不一致，增加 `--iw` 到 2.5 或 3，重新生成

### 一致性检查清单
- ✓ 人物外貌是否一致（年龄、发型、五官）
- ✓ 姿态是否一致（站立角度、头部角度）
- ✓ 服装是否一致（连衣裙颜色、款式、长度）
- ✓ 表情是否一致（微笑、眼神方向）
- ✓ 只有光影和背景改变

### 参数调优建议
| 问题 | 解决方案 |
|------|----------|
| 人物不一致 | 增加 `--iw` 到 2.5 或 3 |
| 光影改变不明显 | 降低 `--iw` 到 1.5，增加光影描述权重 |
| 人物轻微变形 | 增加 `(keep character stable:1.3)` 到正面提示词 |
| 背景变化不够 | 在负面提示词中添加 `--no original background` |

---

## 示例 6：视频图生图（保持人物一致性）

### 场景描述
用户上传一张人像照片，希望生成一段5秒视频，保持人物完全不变，只让光影从自然光逐渐过渡到电影感的伦勃朗光。

### 提示词
```
MUST strictly maintain: Character's appearance, pose, clothing, expression throughout entire video.

Character: 25-year-old female with (long black hair:1.5), (oval face:1.3),
(big eyes with double eyelids:1.2), high nose bridge, thin lips,
white cotton knee-length dress, standing pose, gentle smile,
looking slightly to the right.

Lighting transition: Starting with natural soft front light,
(gradually transition to Rembrandt lighting:1.3) from top-left over 5 seconds,
(cold blue rim light:1.2) fades in from behind,
(contrast increases:1.2) from high key to low key Chiaroscuro,
background transitions from simple to rainy street with neon lights,
(volumetric lighting fades in:1.2), (smoky atmosphere builds up:1.1).

MUST NOT change: No changes to character appearance, pose, clothing, expression,
no character deformation, no character movement except subtle breathing.

--camera_move subtle --duration 5 --character_consistency 0.95
```

### 关键要点
- `--character_consistency 0.95`：极高人物一致性参数
- `throughout entire video`：强调整个视频过程保持一致
- `gradually transition`：描述光影的渐变过程
- `fades in / builds up`：描述光影逐渐出现的过程
- `MUST NOT change`：明确禁止改变人物

### 使用方法
1. 在视频生成平台上传原图作为第一帧
2. 设置 `--character_consistency 0.95`
3. 使用上述提示词生成视频
4. 检查视频中人物是否保持一致
5. 如不一致，增加 `--character_consistency` 到 0.98，重新生成

---

## 使用技巧总结

### 1. 叙事优先
每个示例都从"这个场景的情绪是什么"开始：
- 悬疑惊悚：压抑、不安
- 浪漫爱情：温暖、柔和
- 历史史诗：力量、权威
- 科幻冷峻：疏离、未来
- 图生图：主体严格一致，只改变光影

### 2. 光影一致性
所有示例的光影都是逻辑一致的：
- 主光方向明确
- 修饰光位置合理
- 阴影遵循物理规律
- 光质与叙事情绪匹配

### 3. 微细节的层次
根据场景调整细节程度：
- 近景特写：强调皮肤细节（毛孔、微汗、绒毛）
- 中景：关注环境和皮肤细节平衡
- 远景：强调大气和风化纹理

### 4. 负面提示词的针对性
每个示例都包含针对性负面提示词：
- 写实人像：避免塑料皮肤
- 科幻场景：避免胶片颗粒
- 图生图：避免改变主体特征
- 文艺场景：避免过度戏剧化
