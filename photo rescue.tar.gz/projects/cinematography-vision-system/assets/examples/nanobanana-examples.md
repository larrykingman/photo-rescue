# NanoBanana 提示词示例

## 示例 1：悬疑惊悚场景（雨夜侦探）

### 提示词
```
exhausted middle-aged detective, smoking cigarette, sweat on forehead,
looking off-camera, intense expression, raincoat, hat,
rainy street at night, neon lights, wet pavement,
dirty foreground with rain-streaked glass, blurry,
(Rembrandt lighting from top-left:1.2), (cold blue rim light:1.2),
low key, (chiaroscuro:1.3), volumetric lighting,
smoky atmosphere, Tyndall effect,
ARRI Alexa Mini, 35mm anamorphic lens, (Kodak Vision3 500T:1.2),
Dutch angle, (shallow depth of field:1.3), focus on character,
(visible pores:1.5), (3S subsurface scattering:1.3), micro-sweat,
weathered texture, (film grain:1.2), dust particles,
(cinematic:1.3), (film noir style:1.2), Oscar cinematography,
(teal and orange color grading:1.2),
--quality 2 --style cinematic --ar 2.39:1
--no plastic skin, smooth skin, 3d render, anime, flat lighting, shadowless
```

### 光影架构分析
- **主光**：Rembrandt lighting（权重1.2）- 伦勃朗光
- **修饰光**：cold blue rim light（权重1.2）- 冷蓝色轮廓光
- **对比度**：low key（低调）, chiaroscuro（权重1.3）- 明暗对照法
- **大气**：volumetric lighting + Tyndall effect - 体积光和丁达尔效应

### 光学物理参数
- **摄影机**：ARRI Alexa Mini
- **镜头**：35mm anamorphic lens - 变形宽银幕
- **胶片**：Kodak Vision3 500T（权重1.2）
- **构图**：Dutch angle - 荷兰倾斜
- **景深**：shallow depth of field（权重1.3）- 浅景深

### 微细节
- **皮肤**：visible pores（权重1.5）, 3S subsurface scattering（权重1.3）, micro-sweat
- **环境**：weathered texture, film grain（权重1.2）, dust particles

### 负面提示词
```
--no plastic skin, smooth skin, 3d render, anime, flat lighting, shadowless
```

---

## 示例 7：图生图（保持主体一致性 - 改变光影）

### 场景描述
用户上传一张人像照片，希望将普通柔光改造成电影感的伦勃朗光，同时严格保持人物的外貌、姿态、服装、表情不变。

### 操作步骤
1. 上传原图
2. 输入以下提示词
3. 设置 `--strength 0.4`（控制变化程度）
4. 生成后检查主体一致性

### 提示词
```
MUST strictly maintain: original character appearance, pose, clothing, expression.

Character: 25-year-old female,
(long black hair:1.5), (oval face:1.3),
(big eyes with double eyelids:1.2), high nose bridge, thin lips,
white cotton knee-length dress, standing pose,
gentle smile, (looking slightly to right:1.2).

ONLY change lighting and atmosphere:
Change from natural soft front light to:
(Rembrandt lighting from top-left 45 degrees:1.3),
(cold blue rim light from behind:1.2) to separate from background,
(Low key Chiaroscuro contrast:1.3),
background from simple to rainy street at night,
(volumetric lighting:1.2), (smoky atmosphere:1.1), (Tyndall effect:1.1),
enhance (film grain:1.2), weathered texture, dust particles,
change color grading to (teal and orange:1.2).

--quality 2 --style cinematic --ar 2.39:1 --strength 0.4
--no different face, different pose, different clothing, different expression,
change character appearance, character deformation, plastic skin, smooth skin
```

### 参数说明
- `--strength 0.4` - 变化强度0.4（0.3-0.5为最佳范围，过高会导致主体改变）
- `(long black hair:1.5)` - 高权重强调需要保留的特征
- `MUST strictly maintain` - 强制语言强调主体不变
- `ONLY change` - 明确只改变光影和氛围
- `--no` - 负面提示词禁止改变主体

### 一致性检查清单
- ✓ 人物外貌是否一致（年龄、发型、五官）
- ✓ 姿态是否一致（站立角度、头部角度）
- ✓ 服装是否一致（连衣裙颜色、款式、长度）
- ✓ 表情是否一致（微笑、眼神方向）
- ✓ 只有光影和背景改变

### 参数调优指南

| `--strength` 值 | 效果 | 适用场景 |
|----------------|------|----------|
| 0.2-0.3 | 几乎不改变 | 需要微调时 |
| 0.4-0.5 | **推荐** | 平衡改造效果和主体一致性 |
| 0.6-0.7 | 明显改变 | 主体轻微变化可接受 |
| 0.8+ | 大幅改变 | 不适合图生图 |

### 常见问题解决

**问题1：人物外貌发生变化**
```
解决方案：
- 降低 --strength 到 0.35 或 0.3
- 增加主体描述权重到 1.5 或更高
- 在负面提示词中添加更明确的禁止内容
```

**问题2：光影改变不明显**
```
解决方案：
- 提高 --strength 到 0.45 或 0.5
- 增加光影描述权重到 1.3 或 1.4
- 在负面提示词中添加 `--no original lighting`
```

**问题3：人物轻微变形**
```
解决方案：
- 降低 --strength 到 0.35
- 添加 `(keep character stable:1.3)` 到正面提示词
- 在负面提示词中添加 `--no character deformation`
```

---

## 示例 8：视频图生图（保持人物一致性）

### 场景描述
用户上传一张人像照片，希望生成5秒视频，保持人物完全不变，只让光影从自然光逐渐过渡到伦勃朗光。

### 操作步骤
1. 上传原图作为第一帧
2. 输入以下提示词
3. 设置 `--strength 0.3`（视频需要更低强度）
4. 设置 `--character_consistency 0.95`（极高人物一致性）

### 提示词
```
MUST strictly maintain: original character appearance, pose, clothing,
expression throughout entire video. No character deformation or changes.

Character: 25-year-old female,
(long black hair:1.5), (oval face:1.3),
(big eyes with double eyelids:1.2), high nose bridge, thin lips,
white cotton knee-length dress, standing pose,
gentle smile, (looking slightly to right:1.2).

Lighting transition ONLY:
Starting with natural soft front light,
(gradually transition to Rembrandt lighting:1.3) from top-left over 5 seconds,
(cold blue rim light:1.2) fades in from behind to separate character,
(contrast increases:1.2) from high key to low key Chiaroscuro,
background transitions from simple to rainy street at night,
(volumetric lighting fades in:1.2), (smoky atmosphere builds up:1.1).

MUST NOT change: No changes to character appearance, pose, clothing,
expression, no character deformation, no character movement
except subtle breathing.

--quality 2 --style cinematic --ar 2.39:1 --strength 0.3
--character_consistency 0.95 --duration 5
--no different face, different pose, different clothing, different expression,
character deformation, character movement, plastic skin
```

### 关键参数
- `--strength 0.3` - 变化强度0.3（视频需要更低强度，保持人物稳定）
- `--character_consistency 0.95` - 极高人物一致性（0.9-0.98为推荐范围）
- `gradually transition` - 描述光影的渐变过程
- `fades in / builds up` - 描述元素的逐渐出现
- `throughout entire video` - 强调整个视频过程保持一致
- `MUST NOT change` - 明确禁止改变人物

### 视频生成技巧

**保持人物一致性**：
- 使用极高的 `--character_consistency`（0.95+）
- 使用较低的 `--strength`（0.3-0.4）
- 在每一帧的描述中强调保持人物不变
- 避免复杂的运镜

**光影过渡描述**：
- 使用 `gradually transition` 描述渐变
- 使用 `fades in / fades out` 描述元素出现/消失
- 使用时间状语 `over 5 seconds` 明确过渡时长
- 描述光影的动态变化过程

**避免的问题**：
- ❌ 过高的 `--strength`（>0.5）- 人物容易变形
- ❌ 复杂的运镜 - 增加人物变形风险
- ❌ 大幅度光影变化 - 难以保持人物稳定
- ❌ 过长的视频（>5秒）- 累积变形风险

### 参数对比表

| 场景 | `--strength` | `--character_consistency` | 说明 |
|------|-------------|-------------------------|------|
| 静态图生图 | 0.4-0.5 | 不适用 | 平衡改造效果和一致性 |
| 视频图生图 | 0.3-0.4 | 0.95+ | 极高一致性，低变化强度 |
| 批量图生图 | 0.4-0.5 | 不适用 | 统一参数批量处理 |
| 微调光影 | 0.2-0.3 | 不适用 | 微小变化 |

---

### 提示词
```
young woman with freckles, standing on beach, wind blowing hair,
gentle smile, looking at ocean, longing expression, summer dress,
seaside at sunset, ocean waves, sandy beach, negative space to the right,
golden hour light, (warm golden rim light:1.2), high key,
(soft lighting:1.3), Tyndall effect, warm atmosphere,
Kodak Portra 400, 85mm lens, shallow depth of field,
rule of thirds, focus on face, bokeh background,
visible pores, (3S subsurface scattering:1.3), (peach fuzz:1.2),
natural freckles, soft skin texture, film grain,
(cinematic:1.2), romantic, dreamy, poetic,
(warm orange color palette:1.3),
--quality 2 --style romantic --ar 16:9
--no plastic skin, airbrushed face, 3d render, studio lighting
```

### 光影架构分析
- **主光**：golden hour light - 黄昏光
- **修饰光**：warm golden rim light（权重1.2）- 暖金色轮廓光
- **对比度**：high key - 高调明亮
- **光质**：soft lighting（权重1.3）- 柔光
- **大气**：Tyndall effect - 丁达尔效应

### 光学物理参数
- **胶片**：Kodak Portra 400
- **镜头**：85mm lens - 人像长焦
- **景深**：shallow depth of field - 浅景深
- **构图**：rule of thirds - 三分法
- **背景**：bokeh - 焦外虚化

### 微细节
- **皮肤**：visible pores, 3S subsurface scattering（权重1.3）, peach fuzz（权重1.2）
- **环境**：natural freckles, soft skin texture, film grain

### 负面提示词
```
--no plastic skin, airbrushed face, 3d render, studio lighting
```

---

## 示例 3：历史史诗场景（战场将军）

### 提示词
```
battle-hardened general, riding horse, wearing armor,
determined gaze, stern expression, (wrinkles and scars:1.3),
battlefield, charging, soldiers in background, arrows flying,
explosions, smoke and dust, epic scale,
strong top light, (golden rim light:1.2), medium contrast,
(volumetric lighting:1.3), dynamic lighting from fire,
ARRI Alexa LF, 24mm wide angle lens, Kodak Vision3 500T,
center framing, (deep depth of field:1.2), epic composition,
weathered armor texture, dust particles, (film grain:1.2),
(cinematic:1.3), (epic scale:1.3), Oscar cinematography,
desaturated warm tones,
--quality 2 --style epic --ar 2.39:1
--no plastic skin, 3d render, anime, modern elements
```

### 光影架构分析
- **主光**：strong top light - 强烈顶光
- **修饰光**：golden rim light（权重1.2）- 金色轮廓光
- **对比度**：medium contrast - 中等对比
- **大气**：volumetric lighting（权重1.3）- 体积光穿透烟雾

### 光学物理参数
- **摄影机**：ARRI Alexa LF
- **镜头**：24mm wide angle lens - 广角
- **胶片**：Kodak Vision3 500T
- **构图**：center framing - 中心对称
- **景深**：deep depth of field（权重1.2）- 深景深

### 微细节
- **皮肤**：wrinkles and scars（权重1.3）- 皱纹和伤疤
- **环境**：weathered armor texture, dust particles, film grain（权重1.2）

### 负面提示词
```
--no plastic skin, 3d render, anime, modern elements
```

---

## 示例 4：科幻冷峻场景（未来实验室）

### 提示词
```
futuristic scientist, working, neutral expression,
wearing lab coat, glasses reflecting hologram,
futuristic laboratory, holographic displays, clean environment,
cold environment, negative space,
(cold short lighting:1.2), (blue rim light:1.2), low key,
diffused light, cold atmosphere, subtle volumetric light,
ARRI Alexa LF, 50mm lens, shallow depth of field,
(Dutch angle:1.2), focus on scientist,
subtle visible pores, pristine skin quality, no heavy texture,
minimal film grain, clean look,
(cinematic:1.2), (sci-fi:1.3), futuristic, dystopian,
(cold blue and cyan color palette:1.3),
--quality 2 --style cinematic --ar 16:9
--no plastic skin, warm tones, vintage, heavy film grain
```

### 光影架构分析
- **主光**：cold short lighting（权重1.2）- 冷色短光
- **修饰光**：blue rim light（权重1.2）- 蓝色轮廓光
- **对比度**：low key - 低调
- **光质**：diffused light - 漫射光
- **大气**：subtle volumetric light - 轻微体积光

### 光学物理参数
- **摄影机**：ARRI Alexa LF
- **镜头**：50mm lens - 标准镜头
- **构图**：Dutch angle（权重1.2）- 荷兰倾斜
- **景深**：shallow depth of field - 浅景深

### 微细节
- **皮肤**：subtle visible pores - 细微毛孔
- **环境**：pristine skin quality, clean look, minimal film grain

### 负面提示词
```
--no plastic skin, warm tones, vintage, heavy film grain
```

---

## 示例 5：日系文艺场景（室内阅读）

### 提示词
```
young girl, reading book, focused, peaceful expression,
sitting by window, sunlight on face,
cozy room, old bookshelves, wooden furniture, quiet atmosphere,
soft window light from side, minimal rim light, high key,
diffused lighting, no strong atmosphere,
Kodak Portra 400, 50mm lens, shallow depth of field,
rule of thirds, focus on face, 4:3 aspect ratio,
visible pores, (freckles:1.2), soft skin texture,
minimal film grain, warm and cozy look,
(cinematic:1.2), Japanese film aesthetic, healing,
(muted pastel tones:1.2),
--quality 2 --style artistic --ar 4:3
--no plastic skin, oversaturated, dramatic lighting, sharp shadows
```

### 光影架构分析
- **主光**：soft window light from side - 柔和窗户光
- **修饰光**：minimal rim light - 微弱轮廓光
- **对比度**：high key - 高调明亮
- **光质**：diffused lighting - 漫射光
- **大气**：no strong atmosphere - 无强烈大气

### 光学物理参数
- **胶片**：Kodak Portra 400
- **镜头**：50mm lens - 标准镜头
- **构图**：rule of thirds - 三分法
- **比例**：4:3 - 方屏
- **景深**：shallow depth of field - 浅景深

### 微细节
- **皮肤**：visible pores, freckles（权重1.2）, soft skin texture
- **环境**：minimal film grain, warm and cozy look

### 负面提示词
```
--no plastic skin, oversaturated, dramatic lighting, sharp shadows
```

---

## 示例 6：黑色电影风格（Noir 夜街）

### 提示词
```
mysterious detective, trench coat, brim hat, smoking,
shadowed face, enigmatic expression,
rainy street at night, neon signs, dramatic shadows,
dark alleys, film noir atmosphere,
(Split lighting:1.3), harsh rim light, film noir style,
extreme contrast black and white, volumetric lighting,
dramatic light beams,
ARRI Alexa Mini, 35mm anamorphic lens, black and white film stock,
low angle, (deep shadows:1.3), dramatic composition,
shadowed face, weathered texture, (heavy film grain:1.3),
dust particles, classic noir look,
(cinematic:1.3), (film noir style:1.3), Oscar cinematography,
pure black and white high contrast,
--quality 2 --style noir --ar 2.39:1
--no color, plastic skin, 3d render, anime, flat lighting
```

### 光影架构分析
- **主光**：Split lighting（权重1.3）- 阴阳光
- **修饰光**：harsh rim light - 硬轮廓光
- **对比度**：film noir style, extreme contrast - 黑色电影风格，极致对比
- **大气**：volumetric lighting - 体积光

### 光学物理参数
- **摄影机**：ARRI Alexa Mini
- **镜头**：35mm anamorphic lens - 变形宽银幕
- **质感**：black and white film stock - 黑白胶片
- **构图**：low angle - 低角度
- **阴影**：deep shadows（权重1.3）- 深刻阴影

### 微细节
- **皮肤**：shadowed face - 阴影面部
- **环境**：weathered texture, heavy film grain（权重1.3）

### 负面提示词
```
--no color, plastic skin, 3d render, anime, flat lighting
```

---

## 权重控制说明

### 权重语法
```
关键词:权重值    # 数字权重
(关键词:权重值)  # 括号权重
{关键词:权重值}  # 花括号权重
```

### 权重建议

**高权重（1.2-1.5）**：
- 核心光影效果：`(Rembrandt lighting:1.2)`, `(chiaroscuro:1.3)`
- 重要质感细节：`(visible pores:1.5)`, `(3S subsurface scattering:1.3)`
- 风格标签：`(cinematic:1.3)`, `(film noir style:1.2)`

**中权重（1.0-1.2）**：
- 一般光影：`rim light`, `soft lighting`
- 一般质感：`weathered texture`, `dust particles`

**低权重（0.5-0.8）**：
- 弱化元素：`(romantic:0.5)`, `(bright:0.7)`

**负权重（-1.0 - -1.5）**：
- 避免元素（在--no参数中）：`plastic skin`, `3d render`

## 参数说明

### 通用参数
```
--quality 1-2        # 画面质量（1:普通, 2:高质量）
--style <style>      # 风格（cinematic, realistic, artistic, romantic, epic, noir）
--ar <ratio>         # 画面比例（16:9, 2.39:1, 4:3, 1:1）
```

### 负面提示词
```
--no <keywords>      # 避免的关键词（用逗号分隔）
```

## 使用技巧总结

### 1. 关键词顺序
按重要性排列，前面的权重更高：
```
[主体] > [动作] > [表情] > [环境] > [光影] > [摄影] > [构图] > [质感] > [风格] > [色彩]
```

### 2. 使用括号分组
相关关键词用括号分组：
```
(cinematic:1.3, film grain:1.2, Oscar cinematography),
(Rembrandt lighting:1.2, rim light:1.2, low key),
(visible pores:1.5, 3S subsurface scattering:1.3)
```

### 3. 混合语言
支持中英文混合，专业术语用英文：
```
疲惫的中年侦探, smoking cigarette, sweat on forehead,
伦勃朗光, Rembrandt lighting, 冷蓝色轮廓光, cold blue rim light
```

### 4. 权重平衡
不要对所有关键词都加高权重，只对核心要素加重：
```
visible pores:1.5  # 重要，高权重
weathered texture  # 一般，默认权重
```

### 5. 关键词数量
建议 20-40 个关键词，过少效果不佳，过多会稀释权重。

### 6. 测试迭代
生成后根据效果调整权重和关键词：
```
如果皮肤太光滑 → 增加 (visible pores:1.5)
如果画面不够电影感 → 增加 (cinematic:1.3)
```

### 7. 风格一致性
确保所有关键词服务于同一风格（悬疑/浪漫/史诗/文艺）：
```
悬疑风格：low key, chiaroscuro, Dutch angle, teal and orange
浪漫风格：high key, soft lighting, warm orange, dreamy
史诗风格：medium contrast, volumetric lighting, epic scale, center framing
```

### 8. 负面提示词必须
必须使用 `--no` 参数避免不想要的效果：
```
--no plastic skin, 3d render, anime, flat lighting, shadowless
```
