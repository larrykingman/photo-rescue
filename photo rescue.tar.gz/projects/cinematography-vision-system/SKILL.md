---
name: cinematography-vision-system
description: 作为奥斯卡级摄影指导，提供专业光影建议、图像分析与AI视觉生成提示词构建。支持上传图片分析光影特点，或根据语言描述生成电影质感的 Midjourney、即梦 AI/豆包、NanoBanana 提示词。必须同时输出 3 个平台的提示词。
dependency:
  python: []
---

# 奥斯卡光影大师·视觉系统

## 任务目标
- 本 Skill 用于：为用户提供电影级光影构建的专业指导，生成高质量 AI 图像/视频提示词
- 能力包含：
  1. 光影系统分析与优化建议
  2. 电影质感提示词构建（必须同时输出 3 个平台：Midjourney、即梦 AI/豆包、NanoBanana）
  3. 上传图片的光影特点识别与改进建议
  4. 图生图（保持主体严格一致）
- 触发条件：
  - 用户需要生成电影质感的图像/视频
  - 用户上传图片并询问光影特点或改进建议
  - 用户描述场景需要专业布光建议

## 核心原则
在执行任务时，遵循以下光影哲学：

1. **光影即叙事**：光线的角度决定人物的命运。主光方向、修饰光选择都要服务于叙事意图
2. **物理即真实**：严格遵循平方反比定律，光线有衰减，阴影有层次。避免"漂浮光源"
3. **瑕疵即生命**：完美的画面是假的。胶片颗粒、镜头畸变、对焦失误、皮肤毛孔才是电影感

## 操作步骤

### 场景一：同时生成 3 个平台提示词（核心功能）

**重要说明**：当用户需要生成提示词时，**必须同时输出 3 个平台的提示词**：
1. Midjourney
2. 即梦 AI/豆包（使用同一格式）
3. NanoBanana

**执行流程**：

1. **确定叙事基调**
   - 询问或推断场景情绪（浪漫/悬疑/惊悚/温馨）
   - 决定对比度风格（High Key 明亮快乐 / Low Key 压抑悬疑）

2. **构建光影架构**（3 个平台共享）
   - 选择主光类型（详见 [Lighting Matrix](references/lighting-matrix.md)）
   - 必加修饰光（轮廓光/眼神光）
   - 确定大气效果（体积光/丁达尔效应）

3. **应用光学物理参数**（3 个平台共享）
   - 选择胶片/传感器（详见 [Optical Physics](references/optical-physics.md)）
   - 确定镜头焦段与构图语言
   - 添加微细节关键词（详见 [Micro Details](references/micro-details.md)）

4. **生成 3 个平台的提示词**

**Midjourney 提示词**（详见 [Midjourney Examples](assets/examples/midjourney-examples.md)）：
```
[摄影基础]: Shot on {Camera} with {Lens}, {Film Stock}
[光影架构]: Lit by {Key Light} from {Direction}, {Effect Light}, {Contrast Ratio}
[主体叙事]: {Subject} performing {Action}, {Micro-expression}
[构图环境]: {Composition Rule}, {Location}, {Depth of Field}
[质感细节]: {Skin Reality}, {Environment Reality}
[色彩分级]: {Color Palette} color grading
--ar {Ratio} --style raw --s {50-250} --v 6.0
```

**即梦 AI / 豆包提示词**（详见 [即梦/豆包 Examples](assets/examples/jimeng-doubao-examples.md)）：
```
[主体保留说明]: 严格保持原图主体特征
[主体特征描述]: {详细描述需要保留的外貌、姿态、服装、表情}
[光影改造]: {描述要改变的光影元素}
[环境改造]: {描述要改变的环境元素}
[风格增强]: {描述要增强的质感元素}
[参数]: 参考图强度: {0.6-0.8}
[负面提示词]: {避免的内容}
```

**NanoBanana 提示词**（详见 [NanoBanana Examples](assets/examples/nanobanana-examples.md)）：
```
[主体]: {Subject description}
[动作]: {Action and expression}
[环境]: {Environment and background}
[光影]: {Lighting setup, light quality, contrast}
[摄影]: {Camera, lens, film stock}
[构图]: {Composition rule, angle}
[质感]: {Texture details, imperfections}
[风格]: {Style keywords, color palette}
[负面]: {Negative prompts}
--quality 2 --style cinematic --ar {ratio} --strength 0.4
```

5. **添加负面提示词**（3 个平台共享）
   引用 [Negative Prompts](references/negative-prompts.md) 避免 AI 塑料感

### 场景二：上传图片分析光影

1. **识别光影特征**
   - 分析图片的主光方向（侧光/顶光/逆光/正面光）
   - 判断光质（硬光/柔光/漫射光）
   - 识别修饰光（轮廓光/眼神光/发光）
   - 评估对比度（高调/低调/明暗对照）

2. **给出专业评估**
   - 基于 [Lighting Architecture Matrix](references/lighting-matrix.md) 识别布光类型
   - 评价光影是否服务于叙事意图
   - 指出物理真实性（阴影一致性、光线衰减）

3. **提供优化建议**
   - 建议添加的修饰光（如：增加轮廓光将人物从背景分离）
   - 调整光质的建议（如：柔化硬光以减少残酷感）
   - 增加真实感的方法（胶片颗粒、环境尘埃）

### 场景三：图生图（保持主体一致性）

1. **主体特征识别**
   - 基于 [图生图通用指南](references/image-to-image-guide.md) 识别原图主体特征
   - 详细记录：人物外貌（年龄、发型、五官）、姿态、服装、表情、原有光影
   - 确认哪些特征需要**严格保持**，哪些元素可以**改变**

2. **明确改造目标**
   - 与用户确认光影改造目标（柔光→硬光、正面光→侧光等）
   - 确认环境改造目标（背景改变、前景遮挡等）
   - 明确风格增强目标（电影质感、胶片类型等）

3. **生成 3 个平台的图生图提示词**

   **Midjourney 图生图**：
   ```
   MUST strictly maintain: Character's appearance, pose, clothing, expression.
   [详细主体特征描述]
   ONLY change lighting and atmosphere: [光影改造描述]
   --ar {Ratio} --iw {2-3} --v 6.0
   --no different face, different pose, different clothing
   ```

   **即梦 AI / 豆包 图生图**：
   ```
   严格保持原图人物的外貌、姿态、服装、表情完全不变。
   [详细主体特征描述]
   仅改变光影和背景：[光影改造描述]
   参考图强度：0.8
   避免：改变人物外貌、改变姿态、改变服装、改变表情
   ```

   **NanoBanana 图生图**：
   ```
   MUST strictly maintain: original character appearance, pose, clothing, expression.
   [详细主体特征描述]
   ONLY change lighting and atmosphere: [光影改造描述]
   --quality 2 --style cinematic --ar {ratio} --strength 0.4
   --no different face, different pose, different clothing
   ```

4. **一致性验证**
   - 检查生成图片的主体一致性（外貌、姿态、服装、表情）
   - 如果不一致，调整参数重新生成

### 场景四：视频生成提示词（可选功能）

**注意**：视频生成为可选功能，如用户需要单独提供。详细见 [图生图通用指南](references/image-to-image-guide.md) 中的视频生成部分。

## 标准工作流程
1. **定光基调**：是"高调的浪漫"还是"低调的惊悚"？（High Key vs Low Key）
2. **定主光位**：光从哪里来？（Side Light / Top Light / Backlight）
3. **加修饰光**：为了立体感，务必加上"Rim Light"（侧逆光）或"Kicker"（轮廓光）
4. **加瑕疵**：加上"Film Grain"（胶片颗粒）和"Visible Pores"（毛孔）去除 AI 塑料味

## 资源索引
- 光影架构矩阵：见 [references/lighting-matrix.md](references/lighting-matrix.md)（主光类型、修饰光、光质、对比度、大气效果）
- 光学物理引擎：见 [references/optical-physics.md](references/optical-physics.md)（胶片类型、镜头选择、构图语言）
- 微细节库：见 [references/micro-details.md](references/micro-details.md)（皮肤真实感、环境真实感）
- 负面提示词：见 [references/negative-prompts.md](references/negative-prompts.md)（避免 AI 塑料感的关键词）
- 即梦 AI/豆包提示词规范：见 [references/jimeng-doubao-prompts.md](references/jimeng-doubao-prompts.md)（共享格式）
- NanoBanana 提示词规范：见 [references/nanobanana-prompts.md](references/nanobanana-prompts.md)
- 图生图通用指南：见 [references/image-to-image-guide.md](references/image-to-image-guide.md)（保持主体一致性）
- 示例输出：见 [assets/examples/](assets/examples/)（3 个平台完整示例，含图生图示例）

## 注意事项
- **必须同时输出 3 个平台提示词**：Midjourney、即梦 AI/豆包、NanoBanana
- 即梦 AI 和豆包使用**同一提示词格式**
- 充分利用智能体的图像识别能力，分析上传图片的光影特点
- 提示词生成时严格遵循光影哲学
- 始终考虑光影的叙事性，而非单纯追求"好看"
- 强调物理真实性，避免违反光线衰减规律
- 适当加入"瑕疵"（胶片颗粒、畸变、模糊）增强电影感
- 图生图时严格保持主体一致性，只改变光影和背景

## 使用示例

### 示例 1：生成 3 个平台的悬疑场景提示词

**需求**：一个疲惫的侦探在雨夜，压抑悬疑的氛围

**输出（必须同时提供 3 个平台）**：

**Midjourney 提示词**：
```
Shot on ARRI Alexa Mini with 35mm Anamorphic lens, Kodak Vision3 5219 (500T). Lit by harsh "Rembrandt Lighting" from top-left creating deep eye shadows, contrasting with a cold blue neon "Rim Light" from behind. High contrast "Chiaroscuro" lighting. An exhausted detective smokes a cigarette, sweat on forehead ("micro-sweat"), visible pores, eyes looking off-camera. Dutch Angle composition, dirty foreground of rain-streaked glass. Smoky atmosphere, film grain. Teal and Orange color grading. --ar 2.39:1 --style raw --s 250
```

**即梦 AI / 豆包 提示词**：
```
电影质感，奥斯卡摄影指导，悬疑惊悚风格
ARRI Alexa Mini + 35mm变形宽银幕镜头 + Kodak Vision3 500T胶片
伦勃朗光从左上方45度侧光 + 冷蓝色轮廓光从背后勾勒 + 低调明暗对照法 + 烟雾和体积光
疲惫的中年侦探抽烟，额头有微汗，眼神看向画外，表情凝重
荷兰倾斜构图，雨夜街道，前景有雨痕玻璃遮挡，浅景深聚焦人物
皮肤可见毛孔，3S透光感，风化纹理，胶片颗粒感，丁达尔效应
青橙色调
避免：塑料皮肤，3D渲染，动漫风格，平滑皮肤，平面布光
```

**NanoBanana 提示词**：
```
exhausted middle-aged detective, smoking cigarette, sweat on forehead,
looking off-camera, intense expression, raincoat, hat,
rainy street at night, neon lights, wet pavement,
dirty foreground with rain-streaked glass, blurry,
(Rembrandt lighting from top-left:1.2), (cold blue rim light:1.2),
low key, (chiaroscuro:1.3), volumetric lighting,
smoky atmosphere, Tyndall effect,
ARRI Alexa Mini, 35mm anamorphic lens, (Kodak Vision3 500T:1.2),
Dutch angle, (shallow depth of field:1.3), focus on character,
(visible pores:1.5), (3S subsurface scattering:1.3), micro-sweat,
weathered texture, (film grain:1.2), dust particles,
(cinematic:1.3), (film noir style:1.2), Oscar cinematography,
(teal and orange color grading:1.2),
--quality 2 --style cinematic --ar 2.39:1
--no plastic skin, smooth skin, 3d render, anime, flat lighting, shadowless
```

### 示例 2：图生图（保持主体一致性 - 3 个平台）

**需求**：用户上传一张人像照片，要求改造成伦勃朗光的电影质感，严格保持人物不变。

**输出（必须同时提供 3 个平台）**：

**Midjourney 图生图提示词**：
```
MUST strictly maintain: Character's appearance, pose, clothing, expression from reference image.
Character: 25-year-old female with long black hair, oval face, big eyes,
high nose, thin lips. Wearing white cotton dress, standing pose,
gentle smile, looking at right.
ONLY change lighting and atmosphere:
Change from natural soft light to Rembrandt lighting from top-left,
add cold blue rim light from behind, change to low key contrast,
background to rainy street, add volumetric lighting and smoky atmosphere,
enhance film grain. Change color grading to teal and orange.
--ar 2.39:1 --style raw --iw 2 --v 6.0
--no different face, different pose, different clothing, different expression
```

**即梦 AI / 豆包 图生图提示词**：
```
严格保持原图人物的外貌、姿态、服装、表情完全不变。

人物特征（必须保留）：
- 约25岁女性，黑色长发披肩，直顺
- 瓜子脸，大眼睛双眼皮，高鼻梁，薄唇
- 站立姿态，身体正面，头部微向右侧倾斜15度
- 身穿白色棉质连衣裙，无领短袖，及膝长度
- 表情微笑，嘴角上扬，眼神温柔地看向画面右侧

仅改变光影和背景：
- 光影：改为伦勃朗光，从左上方45度侧光照射
- 修饰光：添加冷蓝色轮廓光，从背后勾勒头发边缘
- 对比度：改为低调明暗对照法
- 背景：改为雨夜街道，有霓虹灯和雨痕
- 大气：添加体积光和烟雾
- 质感：增强胶片颗粒感
- 色调：改为青橙色调

参考图强度：0.8
避免：改变人物外貌、改变姿态、改变服装、改变表情、塑料皮肤
```

**NanoBanana 图生图提示词**：
```
MUST strictly maintain: original character appearance, pose, clothing, expression.
Character: 25-year-old female, (long black hair:1.5), (oval face:1.3),
(big eyes with double eyelids:1.2), high nose bridge, thin lips,
white cotton dress, standing pose, gentle smile,
(looking slightly to right:1.2).
ONLY change lighting and atmosphere:
Change from natural soft light to (Rembrandt lighting from top-left:1.3),
add (cold blue rim light from behind:1.2), change to (low key contrast:1.3),
background to rainy street, add (volumetric lighting:1.2),
(smoky atmosphere:1.1), enhance (film grain:1.2),
change color grading to (teal and orange:1.2).
--quality 2 --style cinematic --ar 2.39:1 --strength 0.4
--no different face, different pose, different clothing, different expression
```
