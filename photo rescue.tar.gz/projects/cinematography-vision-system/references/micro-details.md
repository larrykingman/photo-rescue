# 微细节库

## 目录
- [皮肤真实感](#皮肤真实感)
- [环境真实感](#环境真实感)
- [使用指南](#使用指南)

## 概览
微细节是区分 AI 生成图像和真实摄影的关键。AI 倾向于生成"完美"的表面，导致塑料感。通过添加真实的微观细节，可以显著增强画面的质感和可信度。

## 皮肤真实感

### Subsurface Scattering（3S 材质 / 皮肤透光感）
- **定义**：光线穿透皮肤表层，在真皮层散射后反射出来的物理现象
- **视觉效果**：
  - 耳朵、鼻翼、嘴唇等薄皮肤呈现红色透光感
  - 强逆光下，皮肤边缘呈现橙红色
- **叙事效果**：
  - 生命力
  - 真实感
  - 柔和感
- **提示词关键词**：
  - `subsurface scattering`
  - `3S skin material`
  - `skin translucency`
  - `backlit skin glow`

### Visible Pores（可见毛孔）
- **定义**：皮肤表面的天然纹理
- **视觉效果**：
  - 鼻翼、脸颊的细小孔洞
  - 自然的不均匀表面
- **重要性**：
  - 拒绝"塑料脸"
  - 区分真实皮肤和渲染皮肤
- **提示词关键词**：
  - `visible pores`
  - `skin texture`
  - `natural skin grain`
  - `realistic skin`

### Skin Texture（皮肤肌理）
- **定义**：皮肤的质感、粗糙度、光泽度
- **视觉效果**：
  - 细微的凹凸不平
  - 自然的光泽反射
  - 不同区域的光泽差异（T区 vs U区）
- **提示词关键词**：
  - `skin texture`
  - `micro skin details`
  - `natural skin surface`
  - `realistic skin sheen`

### Micro-sweat（微汗）
- **定义**：皮肤表面细微的汗水
- **视觉效果**：
  - 前额、上唇的细小汗珠
  - 皮肤表面的湿感
  - 高光反射增强
- **叙事效果**：
  - 焦灼感
  - 劳累感
  - 紧张感
  - 炎热环境
- **提示词关键词**：
  - `micro-sweat`
  - `beads of sweat`
  - `perspiration`
  - `damp skin`

### Peach Fuzz（面部绒毛）
- **定义**：面部细微的细软毛发
- **视觉效果**：
  - 逆光下，面部边缘呈现金色光晕
  - 面颊、下巴的细软绒毛
- **重要性**：
  - 仅在特定光线下可见
  - 显著增加真实感
  - 区别于 3D 渲染
- **提示词关键词**：
  - `peach fuzz`
  - `facial hair`
  - `fine facial hairs`
  - `velum hairs`

### Natural Blemishes（自然瑕疵）
- **定义**：皮肤的天然不完美
- **视觉效果**：
  - 雀斑（freckles）
  - 痘印（acne scars）
  - 皱纹（wrinkles）
  - 色斑（age spots）
  - 红血丝（broken capillaries）
- **叙事效果**：
  - 年龄感
  - 生活经历
  - 真实人物
  - 拒绝"完美"偶像感
- **提示词关键词**：
  - `natural blemishes`
  - `freckles`
  - `acne scars`
  - `age spots`
  - `broken capillaries`

## 环境真实感

### Weathered Texture（风化纹理）
- **定义**：物体表面因长期使用或暴露在环境中产生的纹理
- **视觉效果**：
  - 木材的裂纹和剥落
  - 金属的锈蚀
  - 墙壁的剥落和污渍
  - 织物的磨损和起球
- **叙事效果**：
  - 时间流逝
  - 生活痕迹
  - 质感层次
- **提示词关键词**：
  - `weathered texture`
  - `worn out surface`
  - `aged material`
  - `distressed finish`
  - `cracked paint`
  - `rusted metal`

### Dust Particles（空气灰尘）
- **定义**：悬浮在空气中的微小颗粒
- **视觉效果**：
  - 体积光中飞舞的尘埃
  - 空气的"厚度"感
  - 光束中的亮点
- **叙事效果**：
  - 空间的真实感
  - 时间凝固感
  - 丁达尔效应的基础
- **提示词关键词**：
  - `dust particles`
  - `atmospheric dust`
  - `floating dust`
  - `particulates in air`

### Fingerprints on glass（玻璃指纹）
- **定义**：玻璃表面的人为痕迹
- **视觉效果**：
  - 模糊的指纹
  - 手掌印
  - 油渍
- **叙事效果**：
  - 人为痕迹
  - 镜头前的真实感
  - 窥视视角
  - 生活化场景
- **提示词关键词**：
  - `fingerprints on glass`
  - `smudged glass`
  - `handprints on window`
  - `oily residue`

### Fabric Texture（织物纹理）
- **定义**：布料的织造纹理和质感
- **视觉效果**：
  - 粗麻布的粗糙
  - 丝绸的光滑
  - 牛仔布的斜纹
  - 毛织品的起球
- **叙事效果**：
  - 材料质感
  - 阶层暗示
  - 场景氛围
- **提示词关键词**：
  - `fabric texture`
  - `weave pattern`
  - `cloth material`
  - `textile detail`
  - `rough fabric`
  - `fine weave`

### Raindrops（雨滴）
- **定义**：雨水的具体形态
- **视觉效果**：
  - 雨丝（快速下落的雨滴）
  - 雨滴溅射
  - 玻璃上的水珠
  - 湿润表面的反射
- **叙事效果**：
  - 情绪化天气
  - 悲伤/忧郁
  - 洗净/重生
- **提示词关键词**：
  - `raindrops`
  - `rain streaks`
  - `water droplets`
  - `wet surfaces`

### Lens Flare（镜头炫光）
- **定义**：光线在镜头内部反射产生的光斑
- **视觉效果**：
  - 多边形光斑
  - 横向拉丝（变形宽银幕）
  - 整体画面泛白
- **叙事效果**：
  - 现场感
  - 电影感
  - 情绪化氛围
- **提示词关键词**：
  - `lens flare`
  - `anamorphic lens flare`
  - `horizontal streaks`
  - `glare`

### Chromatic Aberration（色差）
- **定义**：镜头无法完美聚焦所有波长的光线，导致边缘出现彩色边缘
- **视觉效果**：
  - 高对比度边缘的蓝/红边缘
  - 画面边缘的色彩分离
- **叙事效果**：
  - 真实镜头特征
  - 强对比场景
- **提示词关键词**：
  - `chromatic aberration`
  - `color fringing`
  - `lens distortion`

## 使用指南

### 人像场景必备细节
1. **皮肤基础层**：
   - `visible pores`（可见毛孔）
   - `skin texture`（皮肤纹理）
   - `subsurface scattering`（皮肤透光感）

2. **逆光场景添加**：
   - `peach fuzz`（面部绒毛）
   - `backlit skin glow`（逆光皮肤发光）

3. **特定情绪添加**：
   - 紧张/劳累：`micro-sweat`（微汗）
   - 成熟角色：`natural blemishes`（自然瑕疵）
   - 年轻角色：`freckles`（雀斑）

### 环境场景必备细节
1. **室内场景**：
   - `dust particles`（空气灰尘）
   - `weathered texture`（风化纹理）
   - `fabric texture`（织物纹理）

2. **窗边/玻璃场景**：
   - `fingerprints on glass`（玻璃指纹）
   - `raindrops`（雨滴，如适用）

3. **户外场景**：
   - `weathered texture`（风化纹理）
   - `atmospheric dust`（大气灰尘）

### 增强电影感的技巧

1. **避免完美**
   - 拒绝：`perfect skin`, `smooth skin`, `airbrushed face`
   - 添加：`skin imperfections`, `realistic texture`

2. **增加质感层次**
   - 近景：聚焦皮肤细节
   - 中景：关注织物和环境纹理
   - 远景：增加大气灰尘和风化痕迹

3. **光线下才可见**
   - 某些细节（如 `peach fuzz`）仅在逆光下可见
   - 在提示词中明确说明光照条件：
     - `backlit, showing peach fuzz`
     - `side light, emphasizing skin texture`

4. **材质对应**
   - 皮肤：`subsurface scattering`, `visible pores`
   - 金属：`rusted`, `scratched`
   - 木材：`weathered`, `cracked`
   - 玻璃：`fingerprints`, `smudged`

## 完整示例

### 人像特写（近景）
```
Subject: close-up portrait of an elderly man
Skin details: visible pores, wrinkles, age spots, broken capillaries, subsurface scattering on ears
Atmosphere: dust particles in light
Technical: 85mm lens, f/1.8, shallow DOF
```

### 室内场景（中景）
```
Subject: woman reading in old library
Environment: weathered bookshelves, dust particles floating in light, fabric texture of curtains
Skin: skin texture, subtle peach fuzz on cheek
Atmosphere: tyndall effect from window light
```

### 户外场景（远景）
```
Subject: lonely figure on abandoned pier
Environment: weathered wood texture, rusted metal, atmospheric haze, rain streaks
Lighting: overcast, diffuse light
Color: muted teal and orange
```

## 常见错误

❌ **过度使用细节**
- 错误：在远距离场景强调皮肤毛孔
- 正确：根据镜头距离选择合适的细节层次

❌ **不匹配的细节**
- 错误：科幻未来角色的粗糙皮肤
- 正确：根据场景风格调整细节（未来角色皮肤可能更光滑）

❌ **忽略光照条件**
- 错误：正面光下要求可见 peach fuzz
- 正确：明确光照条件（`backlit, revealing peach fuzz`）

❌ **忘记叙事目的**
- 错误：在浪漫场景过度强调瑕疵
- 正确：根据叙事需求调整细节程度
