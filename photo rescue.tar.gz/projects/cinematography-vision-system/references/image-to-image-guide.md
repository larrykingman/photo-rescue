# 图生图通用指南

## 目录
- [核心原则](#核心原则)
- [主体特征识别](#主体特征识别)
- [提示词构建](#提示词构建)
- [平台参数说明](#平台参数说明)
- [一致性验证](#一致性验证)
- [常见问题](#常见问题)

## 核心原则

图生图的核心挑战是**保持主体严格一致性**，只改变光影与氛围。

**绝对原则**：
1. **主体特征不可变**：外貌、姿态、服装、表情必须完全保持原图
2. **光影氛围可改变**：主光方向、光质、对比度、背景、大气效果可以改变
3. **先识别后生成**：必须先详细识别原图主体特征，再生成提示词
4. **验证输出**：生成图片后必须验证主体一致性

## 主体特征识别

在生成图生图提示词之前，必须先仔细识别原图的所有主体特征：

### 外貌特征（必须保持）
- 年龄段（青年/中年/老年）
- 发型（颜色、长度、卷直、造型）
- 脸型（圆脸/方脸/瓜子脸/长脸）
- 眼睛（大小、形状、单双眼皮、颜色）
- 鼻子（高/塌、宽/窄）
- 嘴唇（厚/薄、形状）
- 其他特征（痣、疤痕、皱纹等）

### 姿态与动作（必须保持）
- 身体姿态（站立/坐着/躺下/侧身/正面）
- 手部位置和动作
- 头部倾斜角度
- 腿部和脚的摆放

### 服装与配饰（必须保持）
- 服装类型（T恤/连衣裙/西装等）
- 服装颜色和图案
- 配饰（眼镜、帽子、项链、手表等）

### 表情（必须保持）
- 基本表情（微笑/严肃/惊讶/思考等）
- 眼神方向
- 微表情细节（如嘴角的弧度）

### 原有光影（需要记录，但可能改变）
- 主光方向
- 光质（硬光/柔光）
- 对比度
- 环境光颜色

## 提示词构建

### 第一步：主体保留声明
在提示词开头明确声明"必须保持主体特征"：

**Midjourney**：
```
MUST strictly maintain: Character's appearance, pose, clothing, expression from reference image.
```

**即梦 AI / 豆包**：
```
严格保持原图人物的外貌、姿态、服装、表情完全不变。
```

**NanoBanana**：
```
MUST strictly maintain: original character appearance, pose, clothing, expression.
```

### 第二步：详细主体特征描述
根据识别结果，详细描述需要保持的主体特征：

**示例**（以一张25岁女性人像为例）：

**Midjourney / NanoBanana**：
```
Character: 25-year-old female with long black hair, oval face, big eyes,
high nose, thin lips. Wearing white cotton dress, standing pose,
gentle smile, looking at right.
```

**即梦 AI / 豆包**：
```
人物特征（必须保留）：
- 约25岁女性，黑色长发披肩，直顺
- 瓜子脸，大眼睛双眼皮，高鼻梁，薄唇
- 站立姿态，身体正面，头部微向右侧倾斜15度
- 身穿白色棉质连衣裙，无领短袖，及膝长度
- 表情微笑，嘴角上扬，眼神温柔地看向画面右侧
```

### 第三步：明确改造目标
明确只改变光影和氛围，不改变主体：

**Midjourney**：
```
ONLY change lighting and atmosphere:
```

**即梦 AI / 豆包**：
```
仅改变光影和背景：
```

**NanoBanana**：
```
ONLY change lighting and atmosphere:
```

然后具体描述要改变的光影和氛围：
- 光影改造（主光方向、光质、对比度）
- 环境改造（背景、前景）
- 大气效果（体积光、烟雾、雨等）
- 质感增强（胶片颗粒、真实感）

### 第四步：添加负面提示词
明确禁止改变主体特征：

**Midjourney / NanoBanana**：
```
--no different face, different pose, different clothing, different expression
```

**即梦 AI / 豆包**：
```
避免：改变人物外貌、改变姿态、改变服装、改变表情、塑料皮肤
```

## 平台参数说明

### Midjourney 图生图参数
```
--ar {Ratio}        # 宽高比（如 2.39:1, 16:9, 1:1）
--iw {2-3}          # Image Weight（图像权重），2-3表示强烈参考原图
--style raw         # 禁用默认审美风格，使用原始风格
--v 6.0             # 使用 Midjourney V6 版本
```

**关键参数：`--iw 2-3`**
- `--iw 0.5-1`：微弱参考，主要依据提示词
- `--iw 1-2`：中等参考，平衡原图和提示词
- `--iw 2-3`：强烈参考，严格保持原图特征（推荐用于图生图）

### 即梦 AI / 豆包 图生图参数
```
参考图强度: {0.6-0.8}  # 0.6-0.8 表示中等到强烈的参考
```

**关键参数：`参考图强度: 0.8`**
- `0.6-0.7`：中等参考，允许一定变化
- `0.8-0.9`：强烈参考，严格保持原图特征（推荐用于图生图）

### NanoBanana 图生图参数
```
--quality 2         # 质量等级（2 为高质量）
--style cinematic   # 电影风格
--ar {ratio}        # 宽高比
--strength 0.4      # 变化强度，0.4 表示较弱的变化，强烈保持原图
```

**关键参数：`--strength 0.4`**
- `0.6-0.8`：较强变化，允许较大改变
- `0.4-0.5`：中等变化，保持大部分特征
- `0.2-0.3`：较弱变化，强烈保持原图特征（推荐用于图生图）

## 一致性验证

生成图片后，必须验证以下方面的一致性：

### 验证清单
- [ ] **外貌一致性**：年龄、发型、脸型、五官是否一致？
- [ ] **姿态一致性**：身体姿态、手部位置、头部角度是否一致？
- [ ] **服装一致性**：服装类型、颜色、图案是否一致？
- [ ] **表情一致性**：基本表情、眼神方向是否一致？
- [ ] **光影改变**：光影是否按预期改变了？（只验证光影是否改变，不要求一致）
- [ ] **氛围改变**：背景、大气效果是否按预期改变了？

### 不一致时的处理
如果验证发现主体不一致：
1. 调整参数（增加 `--iw` 值或 `参考图强度`，降低 `--strength`）
2. 在提示词中强化主体描述（添加更详细的特征关键词）
3. 重新生成

## 常见问题

### Q1: 生成图片改变了人物外貌怎么办？
**解决方案**：
- Midjourney：增加 `--iw` 值到 2.5-3
- 即梦 AI / 豆包：增加 `参考图强度` 到 0.85-0.9
- NanoBanana：降低 `--strength` 到 0.3-0.4
- 在提示词中强化外貌描述（如 `(oval face:1.5)`, `(big eyes:1.3)`）

### Q2: 生成图片改变了人物姿态怎么办？
**解决方案**：
- 在提示词中明确描述姿态（如 `standing pose`, `looking at right`）
- 添加负面提示词（如 `--no different pose`）
- Midjourney：使用 `--iw 3` 强烈参考原图

### Q3: 光影改变不够明显怎么办？
**解决方案**：
- 在提示词中强调光影改造（如 `(Rembrandt lighting:1.5)`, `(low key contrast:1.3)`）
- 降低 `--iw` 值或 `参考图强度`（如 Midjourney 用 `--iw 2`, 即梦 AI 用 `参考图强度 0.7`）
- NanoBanana：增加 `--strength` 到 0.5-0.6

### Q4: 如何平衡主体一致性和光影改变？
**解决方案**：
- Midjourney：使用 `--iw 2-2.5` 在保持主体和允许改变之间平衡
- 即梦 AI / 豆包：使用 `参考图强度 0.75-0.8` 在保持主体和允许改变之间平衡
- NanoBanana：使用 `--strength 0.4-0.5` 在保持主体和允许改变之间平衡

## 示例

### 示例 1：改造成伦勃朗光（Midjourney）

**原图描述**：25岁女性，长发，白裙，站立，微笑，自然光

**提示词**：
```
MUST strictly maintain: Character's appearance, pose, clothing, expression from reference image.
Character: 25-year-old female with long black hair, oval face, big eyes,
high nose, thin lips. Wearing white cotton dress, standing pose,
gentle smile, looking at right.
ONLY change lighting and atmosphere:
Change from natural soft light to Rembrandt lighting from top-left,
add cold blue rim light from behind, change to low key contrast,
background to rainy street, add volumetric lighting and smoky atmosphere,
enhance film grain. Change color grading to teal and orange.
--ar 2.39:1 --style raw --iw 2.5 --v 6.0
--no different face, different pose, different clothing, different expression
```

### 示例 2：改造成电影质感（即梦 AI / 豆包）

**原图描述**：中年男性，西装，坐着，严肃，办公室灯光

**提示词**：
```
严格保持原图人物的外貌、姿态、服装、表情完全不变。

人物特征（必须保留）：
- 中年男性，约45岁，黑色短发
- 国字脸，浓眉，眼睛深褐色
- 高鼻梁，厚嘴唇
- 身穿深蓝色西装，白色衬衫，深色领带
- 坐在办公椅上，身体微向前倾，双手放在桌上
- 表情严肃，眼神直接看向镜头

仅改变光影和背景：
- 光影：改为伦勃朗光，从左上方45度侧光照射，增加眼神光
- 修饰光：添加暖橙色轮廓光，从背后勾勒头发和肩膀
- 对比度：改为中低调对比度，增加戏剧性
- 背景：改为暗调背景，有光束和烟雾
- 大气：添加体积光和细微的烟雾
- 质感：增强胶片颗粒感，增加皮肤质感
- 色调：改为暖橙色和深蓝色的电影色调

参考图强度：0.8
避免：改变人物外貌、改变姿态、改变服装、改变表情、塑料皮肤
```

### 示例 3：改造成悬疑氛围（NanoBanana）

**原图描述**：年轻女性，休闲装，站着，微笑，自然光

**提示词**：
```
MUST strictly maintain: original character appearance, pose, clothing, expression.
Character: 20-year-old female, (long wavy brown hair:1.5), (round face:1.3),
(blue eyes:1.2), button nose, full lips,
casual jeans and t-shirt, standing pose, small smile,
(looking at camera:1.2).
ONLY change lighting and atmosphere:
Change from natural soft light to (Rembrandt lighting from top-left:1.3),
add (cold blue rim light from behind:1.2), change to (low key contrast:1.3),
background to abandoned warehouse, add (volumetric lighting:1.2),
(smoky atmosphere:1.1), enhance (film grain:1.2),
change color grading to (cool blue and dark green:1.2).
--quality 2 --style cinematic --ar 2.39:1 --strength 0.4
--no different face, different pose, different clothing, different expression
```

## 视频生成提示词（可选）

如果用户需要生成视频，在图生图的基础上添加以下元素：

### 动态元素描述
- **光线在变吗？**：光束移动、阴影变化、光强变化
- **环境在动吗？**：风吹、下雨、烟雾流动、行人走动
- **人物在动吗？**：微表情变化、眼神转动、呼吸起伏

### 运镜设计
- **推拉镜头**：缓慢推进增加紧张感，缓慢拉开展示环境
- **摇移镜头**：跟随人物移动，创造不安感
- **运镜动机**：展示环境、聚焦情绪、创造叙事张力

### 视频提示词示例（即梦 AI / 豆包）

**需求**：侦探在雨夜抽烟的悬疑氛围视频

**提示词**：
```
严格保持原图人物的外貌、姿态、服装、表情完全不变。

人物特征（必须保留）：
- 中年男性，约45岁，黑色短发
- 国字脸，浓眉，眼睛深褐色
- 高鼻梁，厚嘴唇
- 身穿深蓝色风衣
- 站立姿态，身体正面
- 表情凝重，眼神看向画外右侧
- 手中拿着香烟，烟雾缓缓升起

仅改变光影和背景：
- 光影：伦勃朗光从左上方45度侧光照射
- 修饰光：冷蓝色轮廓光从背后勾勒头发和肩膀
- 对比度：低调明暗对照法
- 背景：雨夜街道，霓虹灯闪烁
- 大气：体积光和烟雾弥漫

动态元素：
- 雨水不断落下，在地面上溅起水花
- 烟雾从香烟升起，缓缓飘动
- 背景中的霓虹灯有微弱的闪烁
- 人物有轻微的呼吸起伏

运镜：
- 缓慢推进镜头，从全身镜头缓慢推进到中景镜头
- 聚焦人物表情，营造紧张氛围
- 保持荷兰倾斜构图，增加不安感

参考图强度：0.8
避免：改变人物外貌、改变姿态、改变服装、改变表情、塑料皮肤
```
