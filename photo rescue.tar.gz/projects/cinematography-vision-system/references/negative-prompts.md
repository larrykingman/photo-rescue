# 负面提示词库

## 目录
- [通用负面提示词](#通用负面提示词)
- [光影特定负面提示词](#光影特定负面提示词)
- [皮肤质感负面提示词](#皮肤质感负面提示词)
- [风格负面提示词](#风格负面提示词)

## 概览
负面提示词用于告诉 AI **不要**生成什么。这是避免 AI 生成"塑料感"、"3D 渲染感"或其他不真实效果的关键工具。

## 通用负面提示词

### 避免 3D 渲染感
```
(3d render:1.5), (3d model:1.3), (cgi:1.3), (rendered:1.2)
```

### 避免卡通/动漫风格
```
(anime:1.2), (manga:1.2), (cartoon:1.2), (drawing:1.2), (sketch:1.2), (illustration:1.2)
```

### 避免塑料皮肤
```
(plastic skin:1.5), (smooth skin:1.3), (airbrushed face:1.3), (perfect skin:1.2), (porcelain skin:1.2), (waxy skin:1.2)
```

### 避免过度对称
```
(perfect symmetry:1.2), (unnatural symmetry:1.1)
```

### 避免过度饱和
```
(over-saturated:1.2), (neon colors:1.1), (oversaturated:1.1)
```

### 避免平面布光
```
(flat lighting:1.3), (evenly lit:1.2), (studio lighting:1.2)
```

### 避免浓妆
```
(makeup heavy:1.2), (heavy makeup:1.2), (artificial makeup:1.1)
```

### 避免卡通眼睛
```
(cartoon eyes:1.2), (anime eyes:1.2), (unnaturally large eyes:1.1)
```

### 避免低质量
```
(low quality:1.2), (blurry:1.2), (out of focus:1.1)
```

### 完整通用组合
```
(plastic skin:1.5), (3d render:1.2), (anime:1.2), (drawing:1.2), smooth skin, airbrushed face, perfect symmetry, flat lighting, evenly lit, over-saturated, studio lighting (unless specified), makeup heavy, cartoon eyes
```

## 光影特定负面提示词

### 避免无阴影
```
(shadowless:1.3), (no shadows:1.2), (flat contrast:1.2)
```

### 避免坏的光影逻辑
```
(bad shadow logic:1.3), (inconsistent lighting:1.2), (floating shadows:1.2), (contradictory shadows:1.2)
```

### 避免漂浮物体
```
(floating objects:1.2), (suspended objects:1.1)
```

### 避免不一致的光源方向
```
(inconsistent lighting direction:1.2), (multiple main lights:1.1), (contradictory light sources:1.1)
```

### 完整光影组合
```
shadowless, flat contrast, bad shadow logic, floating objects, inconsistent lighting direction
```

## 皮肤质感负面提示词

### 避免过度光滑
```
(smooth skin:1.5), (plastic skin:1.5), (waxy skin:1.3), (porcelain skin:1.3), (glass skin:1.2)
```

### 避免过度修饰
```
(airbrushed:1.3), (photoshopped:1.2), (over-processed:1.1), (digitally enhanced:1.1)
```

### 避免不真实质感
```
(synthetic skin:1.2), (artificial skin texture:1.2), (fake skin:1.1)
```

### 避免过度完美
```
(perfect complexion:1.2), (flawless skin:1.2), (immaculate skin:1.1)
```

### 完整皮肤组合
```
plastic skin, smooth skin, waxy skin, airbrushed, over-processed, perfect complexion, flawless skin, no pores, no texture
```

## 风格负面提示词

### 避免插画风格
```
(illustration:1.3), (painting:1.2), (watercolor:1.1), (digital art:1.1), (concept art:1.1)
```

### 避免游戏画面
```
(game screenshot:1.2), (video game graphics:1.2), (uncanny valley:1.1)
```

### 避免低分辨率
```
(low resolution:1.2), (pixelated:1.1), (blurry:1.1), (out of focus:1.1)
```

### 避免滤镜过度
```
(heavily filtered:1.2), (instagram filter:1.1), (vintage filter:1.1)
```

### 完整风格组合
```
illustration, painting, game screenshot, video game graphics, low resolution, heavily filtered
```

## 使用指南

### 在 Midjourney 中使用
```bash
--no "plastic skin, 3d render, anime, drawing, smooth skin, airbrushed face, perfect symmetry, flat lighting, evenly lit, over-saturated, studio lighting, makeup heavy, cartoon eyes, shadowless, flat contrast, bad shadow logic, floating objects, inconsistent lighting direction"
```

### 在提示词后附加
```
--no plastic skin,3d render,anime,smooth skin,flat lighting,shadowless
```

### 根据场景调整
- **写实人像**：重点避免 `plastic skin`, `airbrushed face`, `perfect symmetry`
- **风景场景**：重点避免 `3d render`, `illustration`, `game screenshot`
- **夜景场景**：重点避免 `flat lighting`, `shadowless`, `inconsistent lighting`

## 权重建议

### 高权重（强烈避免）`(1.3 - 1.5)`
- `plastic skin:1.5`
- `3d render:1.5`
- `smooth skin:1.5`

### 中权重（一般避免）`(1.2 - 1.3)`
- `anime:1.2`
- `drawing:1.2`
- `flat lighting:1.3`
- `shadowless:1.3`

### 低权重（轻微避免）`(1.0 - 1.2)`
- `perfect symmetry:1.2`
- `over-saturated:1.2`
- `makeup heavy:1.2`

## 常见问题

### Q：为什么要加这么多负面提示词？
A：AI 默认倾向于生成"完美"的表面，导致塑料感和渲染感。负面提示词是强制 AI 生成真实质感的关键工具。

### Q：权重多少合适？
A：
- 关键问题（如塑料皮肤）用高权重 `(1.5)`
- 一般问题用中权重 `(1.2-1.3)`
- 细节问题用低权重 `(1.0-1.2)`

### Q：所有场景都用相同的负面提示词吗？
A：不是。根据场景调整：
- 写实人像：重点避免皮肤问题
- 风景场景：重点避免渲染感
- 夜景场景：重点避免光影逻辑错误

### Q：负面提示词会破坏正面提示词的效果吗？
A：合理使用不会。负面提示词只是排除不想要的效果，不会影响想要的效果。

## 完整示例

### 写实人像场景
**负面提示词**：
```
--no "plastic skin:1.5, smooth skin:1.5, airbrushed face:1.3, perfect symmetry:1.2, 3d render:1.2, anime:1.2, cartoon eyes:1.2, studio lighting:1.2"
```

### 夜景悬疑场景
**负面提示词**：
```
--no "flat lighting:1.5, shadowless:1.5, bad shadow logic:1.3, inconsistent lighting:1.2, plastic skin:1.2, 3d render:1.2"
```

### 户外风景场景
**负面提示词**：
```
--no "3d render:1.5, illustration:1.3, game screenshot:1.2, painting:1.2, low resolution:1.2, heavily filtered:1.1"
```

### 历史场景
**负面提示词**：
```
--no "3d render:1.5, plastic skin:1.3, modern elements:1.3, digital art:1.2, game graphics:1.2"
```

## 最佳实践

1. **从通用负面提示词开始**
   - 使用上面提供的"完整通用组合"
   - 根据效果微调

2. **逐步调整权重**
   - 如果问题仍存在，增加权重
   - 如果过度影响效果，降低权重

3. **保持简洁**
   - 不要添加过多的负面提示词
   - 专注于核心问题（塑料感、3D感）

4. **与正面提示词配合**
   - 正面提示词强调"真实"、"电影感"
   - 负面提示词排除"塑料"、"3D"
   - 两者配合达到最佳效果

5. **测试和迭代**
   - 生成后分析问题
   - 针对性添加负面提示词
   - 持续优化
