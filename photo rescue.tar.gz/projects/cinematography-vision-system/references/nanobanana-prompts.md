# NanoBanana 提示词规范

## 目录
- [平台特点](#平台特点)
- [提示词结构](#提示词结构)
- [参数详解](#参数详解)
- [权重控制](#权重控制)
- [使用技巧](#使用技巧)

## 平台特点

NanoBanana 是一个通用的 AI 图像生成平台，具有以下特点：

- **标签化格式**：支持逗号分隔的标签式提示词
- **权重控制**：支持通过括号和数字控制关键词权重
- **混合语言**：支持中英文混合描述
- **参数丰富**：支持多种参数控制画面生成

## 提示词结构

NanoBanana 推荐采用标签化结构，使用逗号分隔：

```
[主体], [动作], [表情], [环境], [光影], [摄影], [构图], [质感], [风格], [色彩], --参数
```

### 完整示例结构

```
exhausted middle-aged detective, smoking cigarette, sweat on forehead, looking off-camera, intense expression,
rainy street at night, neon lights, dirty foreground with rain-streaked glass,
Rembrandt lighting from top-left, cold blue rim light from behind, low key, chiaroscuro, volumetric lighting, smoky atmosphere,
ARRI Alexa Mini, 35mm anamorphic lens, Kodak Vision3 500T,
Dutch angle, shallow depth of field, focus on character,
visible pores, 3S subsurface scattering, weathered texture, film grain, dust particles, Tyndall effect,
cinematic, Oscar cinematography, film noir style,
teal and orange color grading,
--quality 2 --style cinematic --no plastic skin, smooth skin, 3d render
```

## 参数详解

### 主体描述

**人物主体**：
- `exhausted middle-aged detective` - 疲惫的中年侦探
- `young woman with freckles` - 有雀斑的年轻女孩
- `battle-hardened general` - 久经沙场的将军
- `futuristic scientist` - 未来科学家

**动作**：
- `smoking cigarette` - 抽烟
- `looking at ocean` - 看向大海
- `riding horse` - 骑马
- `working in laboratory` - 在实验室工作

**表情**：
- `intense expression` - 凝重的表情
- `gentle smile` - 温柔的微笑
- `determined gaze` - 坚定的眼神
- `thinking` - 思考

### 环境描述

**场景**：
- `rainy street at night` - 雨夜街道
- `seaside at sunset` - 海边黄昏
- `battlefield` - 战场
- `futuristic laboratory` - 未来实验室

**前景/背景**：
- `dirty foreground with rain-streaked glass` - 雨痕玻璃前景
- `negative space to the right` - 右侧留白
- `soldiers in background` - 背景士兵
- `holographic display` - 全息显示屏

### 光影描述

**主光类型**：
- `Rembrandt lighting` - 伦勃朗光
- `Split lighting` - 阴阳光
- `Butterfly lighting` - 蝴蝶光
- `Short lighting` - 窄光
- `Broad lighting` - 阔光

**修饰光**：
- `rim light` - 轮廓光
- `backlight` - 逆光
- `hair light` - 发光
- `eye light` - 眼神光

**光质**：
- `hard light` - 硬光
- `soft light` - 柔光
- `diffused light` - 漫射光

**对比度**：
- `high key` - 高调
- `low key` - 低调
- `chiaroscuro` - 明暗对照法
- `medium contrast` - 中等对比

**大气效果**：
- `volumetric lighting` - 体积光
- `Tyndall effect` - 丁达尔效应
- `haze` - 雾感
- `smoky atmosphere` - 烟雾
- `dust particles` - 灰尘

### 摄影参数

**摄影机**：
- `ARRI Alexa Mini` - 数字电影摄影机
- `ARRI Alexa LF` - 大画幅摄影机
- `RED Monstro` - 高分辨率摄影机
- `Sony Venice` - 电影级摄影机

**镜头**：
- `35mm anamorphic lens` - 变形宽银幕镜头
- `50mm lens` - 标准镜头
- `85mm lens` - 人像长焦
- `24mm wide angle lens` - 广角镜头

**胶片**：
- `Kodak Vision3 500T` - 颗粒感强胶片
- `Kodak Portra 400` - 肤色还原胶片
- `Fujifilm Eterna` - 日系电影胶片

### 构图

**构图规则**：
- `rule of thirds` - 三分法
- `center framing` - 中心对称
- `Dutch angle` - 荷兰倾斜
- `negative space` - 留白

**视角**：
- `low angle` - 低角度
- `high angle` - 高角度
- `eye level` - 平视

**景深**：
- `shallow depth of field` - 浅景深
- `deep depth of field` - 深景深
- `focus on character` - 聚焦人物

### 质感细节

**皮肤细节**：
- `visible pores` - 可见毛孔
- `3S subsurface scattering` - 3S透光感
- `micro-sweat` - 微汗
- `freckles` - 雀斑
- `peach fuzz` - 面部绒毛
- `natural blemishes` - 自然瑕疵

**环境纹理**：
- `weathered texture` - 风化纹理
- `fabric texture` - 织物纹理
- `raindrops` - 雨滴
- `fingerprints on glass` - 玻璃指纹

**真实感**：
- `film grain` - 胶片颗粒
- `lens flare` - 镜头炫光
- `chromatic aberration` - 色差

### 风格标签

**叙事风格**：
- `cinematic` - 电影质感
- `film noir style` - 黑色电影风格
- `Oscar cinematography` - 奥斯卡摄影指导
- `epic scale` - 史诗规模
- `art film` - 艺术电影

### 色彩

**色调**：
- `teal and orange` - 青橙色调
- `warm color palette` - 暖色调
- `cool color palette` - 冷色调
- `desaturated` - 低饱和度
- `muted colors` - 柔和色彩

## 权重控制

NanoBanana 支持通过括号和数字控制关键词权重：

### 基本语法
```
关键词:权重值
(关键词:权重值)
{关键词:权重值}
```

### 权重示例

**高权重（强调）**：
```
(visible pores:1.5), (film grain:1.3), (cinematic:1.2)
```

**中权重（正常）**：
```
detective, smoking, Rembrandt lighting
```

**低权重（减弱）**：
```
(romantic:0.5), (bright:0.7)
```

**负权重（避免）**：
```
(plastic skin:-1.5), (3d render:-1.3)
```

### 权重建议

**电影质感要素（高权重）**：
```
(cinematic:1.3), (film grain:1.2), (Oscar cinematography:1.2)
```

**光影效果（中高权重）**：
```
(Rembrandt lighting:1.2), (rim light:1.2), (volumetric lighting:1.1)
```

**质感细节（中权重）**：
```
visible pores, 3S subsurface scattering, weathered texture
```

**避免元素（负权重）**：
```
(plastic skin:-1.5), (3d render:-1.3), (anime:-1.2)
```

## 使用技巧

### 1. 关键词顺序
按重要性排列关键词，前面的权重更高：

```
[主体] > [动作] > [表情] > [光影] > [摄影] > [构图] > [质感] > [风格]
```

### 2. 使用括号分组
相关关键词用括号分组：

```
(cinematic, film grain, Oscar cinematography),
(Rembrandt lighting, rim light, low key),
(visible pores, 3S subsurface scattering, micro-sweat)
```

### 3. 混合语言
支持中英文混合，专业术语用英文：

```
疲惫的中年侦探, smoking cigarette, sweat on forehead,
伦勃朗光, Rembrandt lighting, 冷蓝色轮廓光, cold blue rim light
```

### 4. 添加参数
在提示词末尾添加参数：

```
--quality 2 --style cinematic --ar 16:9
```

### 5. 使用负面提示词
在末尾添加 `--no` 参数：

```
--no plastic skin, smooth skin, 3d render, anime, flat lighting
```

## 完整示例

### 示例 1：悬疑惊悚场景

```
exhausted middle-aged detective, smoking cigarette, sweat on forehead,
looking off-camera, intense expression, raincoat, hat,
rainy street at night, neon lights, wet pavement,
dirty foreground with rain-streaked glass, blurry,
Rembrandt lighting from top-left, (cold blue rim light:1.2), low key,
(chiaroscuro:1.3), volumetric lighting, smoky atmosphere, Tyndall effect,
ARRI Alexa Mini, 35mm anamorphic lens, (Kodak Vision3 500T:1.2),
Dutch angle, (shallow depth of field:1.3), focus on character,
(visible pores:1.5), (3S subsurface scattering:1.3), micro-sweat,
weathered texture, (film grain:1.2), dust particles,
(cinematic:1.3), (film noir style:1.2), Oscar cinematography,
(teal and orange color grading:1.2),
--quality 2 --style cinematic --ar 2.39:1
--no plastic skin, smooth skin, 3d render, anime, flat lighting, shadowless
```

### 示例 2：浪漫爱情场景

```
young woman with freckles, standing on beach, wind blowing hair,
gentle smile, looking at ocean, longing expression, summer dress,
seaside at sunset, ocean waves, sandy beach, negative space to the right,
golden hour light, (warm golden rim light:1.2), high key,
(soft lighting:1.3), Tyndall effect, warm atmosphere,
Kodak Portra 400, 85mm lens, shallow depth of field,
rule of thirds, focus on face, bokeh background,
visible pores, (3S subsurface scattering:1.3), (peach fuzz:1.2),
natural freckles, soft skin texture, film grain,
(cinematic:1.2), romantic, dreamy, poetic,
(warm orange color palette:1.3),
--quality 2 --style romantic --ar 16:9
--no plastic skin, airbrushed face, 3d render, studio lighting
```

### 示例 3：史诗战争场景

```
battle-hardened general, riding horse, wearing armor,
determined gaze, stern expression, scars on face,
battlefield, charging, soldiers in background, arrows flying,
explosions, smoke and dust, epic scale,
strong top light, (golden rim light:1.2), medium contrast,
(volumetric lighting:1.3), dynamic lighting from fire,
ARRI Alexa LF, 24mm wide angle lens, Kodak Vision3 500T,
center framing, (deep depth of field:1.2), epic composition,
(wrinkles and scars:1.3), weathered armor texture,
dust particles, (film grain:1.2),
(cinematic:1.3), (epic scale:1.3), Oscar cinematography,
desaturated warm tones,
--quality 2 --style epic --ar 2.39:1
--no plastic skin, 3d render, anime, modern elements
```

### 示例 4：科幻冷峻场景

```
futuristic scientist, working, neutral expression,
wearing lab coat, glasses reflecting hologram,
futuristic laboratory, holographic displays, clean environment,
cold environment, negative space,
(cold short lighting:1.2), (blue rim light:1.2), low key,
diffused light, cold atmosphere, subtle volumetric light,
ARRI Alexa LF, 50mm lens, shallow depth of field,
(Dutch angle:1.2), focus on scientist,
subtle visible pores, pristine skin quality, no heavy texture,
minimal film grain, clean look,
(cinematic:1.2), (sci-fi:1.3), futuristic, dystopian,
(cold blue and cyan color palette:1.3),
--quality 2 --style cinematic --ar 16:9
--no plastic skin, warm tones, vintage, heavy film grain
```

## 参数说明

### 通用参数
```
--quality 1-2        # 画面质量（1:普通, 2:高质量）
--style <style>      # 风格（cinematic, realistic, artistic等）
--ar <ratio>         # 画面比例（16:9, 2.39:1, 4:3等）
```

### 负面提示词
```
--no <keywords>      # 避免的关键词（用逗号分隔）
```

## 注意事项

1. **关键词数量**：建议 20-40 个关键词，过少效果不佳，过多会稀释权重
2. **权重平衡**：不要对所有关键词都加高权重，只对核心要素加重
3. **语言一致性**：尽量使用同一语言（英文或中文），混合可能降低效果
4. **测试迭代**：生成后根据效果调整权重和关键词
5. **负面提示词**：必须使用，避免 AI 生成不想要的效果
