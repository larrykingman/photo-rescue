# 光学物理引擎

## 目录
- [传感器与胶片类型](#传感器与胶片类型)
- [镜头选择](#镜头选择)
- [构图语言](#构图语言)

## 概览
光学物理引擎定义了视觉作品的基础质感。传感器/胶片、镜头选择和构图语言共同决定了画面的技术特征和叙事风格。

## 传感器与胶片类型

### Kodak Vision3 5219 (500T)
- **类型**：电影胶片，500 ISO
- **特征**：颗粒感强，色彩浓郁，动态范围极高
- **优势**：
  - 夜晚场景首选
  - 强光下不过曝，阴影中保留细节
  - 颗粒质感增强电影感
- **适用场景**：
  - 夜戏、室内戏
  - 惊悚片、犯罪片
  - 复古风格
- **提示词**：`Kodak Vision3 5219 (500T), heavy film grain, rich colors, cinematic`

### Kodak Portra 400
- **类型**：人像胶片，400 ISO
- **特征**：肤色还原之王，温暖，细腻颗粒
- **优势**：
  - 自然肤色还原
  - 色彩柔和过渡
  - 适合日系或人文摄影
- **适用场景**：
  - 人像摄影
  - 日系风格
  - 生活化场景
  - 暖色调叙事
- **提示词**：`Kodak Portra 400, natural skin tones, warm color palette, fine grain`

### Fujifilm Eterna
- **类型**：电影胶片，低反差
- **特征**：色彩淡雅，低反差，柔和
- **优势**：
  - 日系电影感
  - 适合后期调色
  - 色彩过渡自然
- **适用场景**：
  - 日系电影
  - 艺术片
  - 文艺片
  - 冷调叙事
- **提示词**：`Fujifilm Eterna, muted colors, low contrast, Japanese film aesthetic`

### ARRI Alexa LF
- **类型**：数字电影摄影机
- **特征**：动态范围极高，色彩精准，现代电影标杆
- **优势**：
  - 14+ 档动态范围
  - 色彩科学领先
  - 适合高端商业制作
- **适用场景**：
  - 现代电影
  - 商业广告
  - 高预算制作
  - 科幻片
- **提示词**：`ARRI Alexa LF, 4K, pristine image quality, modern cinematic look`

### ARRI Alexa Mini
- **类型**：轻量级数字电影摄影机
- **特征**：与 Alexa LF 同样的画质，更灵活
- **优势**：
  - 适合手持拍摄
  - ARRI 色彩科学
  - 行业标准
- **提示词**：`ARRI Alexa Mini, handheld feel, cinematic motion`

## 镜头选择

### 24mm / 35mm（广角）
- **视角**：宽阔，包含环境
- **特征**：
  - 环境人像，交代关系
  - 轻微畸变增加临场感
  - 主体与背景距离感强
- **叙事效果**：
  - 强调人物与环境的关系
  - 增加戏剧性张力
  - 表现人物的孤独或渺小
- **适用场景**：
  - 全景镜头
  - 环境介绍
  - 戏剧性张力场景
- **提示词**：`24mm lens, wide angle, environmental portrait, slight distortion`

### 50mm / 85mm（标准人像）
- **视角**：接近人眼视角
- **特征**：
  - 标准人像，无畸变
  - 压缩空间，聚焦面部情绪
  - 背景虚化适中
- **叙事效果**：
  - 聚焦人物内心
  - 自然真实感
  - 亲密对话场景
- **适用场景**：
  - 中近景
  - 对话场景
  - 情绪特写
- **提示词**：`50mm lens, natural perspective, focus on emotion`

### 135mm / 200mm（长焦）
- **视角**：狭窄，高度压缩
- **特征**：
  - 极度压缩空间
  - 背景贴近主体
  - 强烈的虚化效果
- **叙事效果**：
  - 孤独感
  - 隔离感
  - 压迫感
  - 被观察者视角
- **适用场景**：
  - 偷拍视角
  - 孤独角色
  - 监控/侦探视角
- **提示词**：`135mm telephoto lens, compressed space, isolation, surveillance feel`

### Anamorphic Lens（变形宽银幕镜头）
- **特征**：
  - 独特的椭圆光斑（bokeh）
  - 横向拉丝炫光（flare）
  - 2.39:1 超宽画幅
- **叙事效果**：
  - 电影史诗感
  - 好莱坞大片感
  - 视觉冲击力强
- **适用场景**：
  - 电影大片
  - 史诗场景
  - 高预算制作
- **提示词**：`35mm anamorphic lens, 2.39:1 aspect ratio, horizontal lens flares, elliptical bokeh`

## 构图语言

### Rule of Thirds（三分法）
- **特征**：将画面分为九宫格，主体位于交叉点
- **叙事效果**：平衡、自然、经典
- **适用场景**：
  - 大多数场景
  - 标准叙事
- **提示词**：`rule of thirds composition, balanced frame`

### Center Framing（韦斯·安德森式对称）
- **特征**：主体居中，完全对称构图
- **叙事效果**：
  - 超现实感
  - 童话感
  - 强迫症般的秩序
  - 幽默感
- **适用场景**：
  - 韦斯·安德森风格
  - 超现实场景
  - 黑色幽默
- **提示词**：`center framing, symmetrical composition, Wes Anderson style`

### Dutch Angle（荷兰倾斜）
- **特征**：画面倾斜，地平线不水平
- **叙事效果**：
  - 不安
  - 混乱
  - 恐惧
  - 心理不稳定
- **适用场景**：
  - 惊悚片
  - 恐怖片
  - 心理崩溃场景
- **提示词**：`Dutch angle, tilted frame, uneasy composition`

### Negative Space（大面积留白）
- **特征**：主体占据画面小部分，大面积空白
- **叙事效果**：
  - 孤独
  - 期待
  - 空虚
  - 思考空间
- **适用场景**：
  - 孤独角色
  - 哲思场景
  - 结束场景
- **提示词**：`negative space, minimalist composition, isolation`

### Dirty Foreground（前景遮挡）
- **特征**：前景有遮挡物（模糊）
- **叙事效果**：
  - 窥视感
  - 增加层次
  - 临场感
  - 旁观者视角
- **适用场景**：
  - 偷拍场景
  - 侦探视角
  - 增加画面深度
- **提示词**：`dirty foreground, blurry foreground elements, depth layering`

## 组合示例

### 悬疑惊悚组合
```
摄影机：ARRI Alexa Mini
镜头：35mm Anamorphic
构图：Dutch Angle（荷兰倾斜）
胶片：Kodak Vision3 5219
效果：前景遮挡（模糊的百叶窗）
```

### 浪漫爱情组合
```
摄影机：Kodak Portra 400
镜头：85mm（长焦）
构图：三分法
胶片：柔光
效果：负空间（留白表达期待）
```

### 史诗战争组合
```
摄影机：ARRI Alexa LF
镜头：24mm 广角
构图：三分法
胶片：硬光质感
效果：体积光、烟雾
```

### 日系文艺组合
```
摄影机：Fujifilm Eterna
镜头：50mm 标准
构图：中心对称
胶片：漫射光
效果：前景遮挡（树叶）
```

## 技术细节

### 景深控制
- **浅景深**（f/1.4 - f/2.8）：
  - 长焦镜头 + 大光圈
  - 聚焦主体，背景模糊
  - 孤立感、情绪聚焦
- **深景深**（f/8 - f/16）：
  - 广角镜头 + 小光圈
  - 前后景都清晰
  - 环境叙事、群像场景

### 对焦策略
- **焦点转移**（Rack Focus）：
  - 从前景焦点移到后景焦点
  - 引导观众注意力
- **脱焦效果**（Out of Focus）：
  - 用于记忆闪回
  - 表达意识模糊

### 画面比例
- **2.39:1（宽银幕）**：史诗感、电影感
- **16:9（宽屏）**：现代电影、电视剧
- **4:3（方屏）**：复古、艺术片、韦斯·安德森
- **9:16（竖屏）**：手机视频、社交媒体
- **1:1（方形）**：Instagram、艺术照片
